
#include "hypot_tiling.h"
#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"

#include "graph/attr_value.h" 

#include "register/tilingdata_base.h"
#include "tiling/tiling_api.h"


namespace optiling {
static ge::graphStatus TilingFunc(gert::TilingContext* context)
{
    size_t usrSize = 256;
  auto ascendcPlatform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    uint32_t sysWorkspaceSize = ascendcPlatform.GetLibApiWorkSpaceSize();
    size_t *currentWorkspace = context->GetWorkspaceSizes(1); // 通过框架获取workspace的指针，GetWorkspaceSizes入参为所需workspace的块数。当前限制使用一块。
    currentWorkspace[0] = usrSize + sysWorkspaceSize; // 设置总的workspace的数值大小，总的workspace空间由框架来申请并管理。
  uint32_t aivNum = ascendcPlatform.GetCoreNumAiv();
  context->SetBlockDim(aivNum);
  HypotTilingData tiling;

  // get shape
  uint32_t arrInput[8], arrOther[8], arrOutput[8], input_size = 1, other_size = 1, mode = 0;
  const gert::StorageShape* input_shape = context->GetInputShape(0);
  const gert::StorageShape* other_shape = context->GetInputShape(1);
  const gert::StorageShape* output_shape = context->GetOutputShape(0);
  arrInput[0] = static_cast<uint32_t>(input_shape->GetStorageShape().GetDimNum());
  arrOther[0] = static_cast<uint32_t>(other_shape->GetStorageShape().GetDimNum());
  arrOutput[0] = static_cast<uint32_t>(output_shape->GetStorageShape().GetDimNum());
  for (int i = 0; i < input_shape->GetStorageShape().GetDimNum(); i++)
  {
    arrInput[i+1] = static_cast<uint32_t>(input_shape->GetStorageShape().GetDim(i));
    input_size *= arrInput[i+1];
  }
  for (int i = 0; i < other_shape->GetStorageShape().GetDimNum(); i++)
  {
    arrOther[i+1] = static_cast<uint32_t>(other_shape->GetStorageShape().GetDim(i));
    other_size *= arrOther[i+1];
  }
  for (int i = 0; i < output_shape->GetStorageShape().GetDimNum(); i++)
    arrOutput[i+1] = static_cast<uint32_t>(output_shape->GetStorageShape().GetDim(i));

  // get type
  ge::DataType tensor_dtype = context->GetInputDesc(0)->GetDataType();
  uint32_t dtype_flag = 2;
  if(tensor_dtype == ge::DT_FLOAT16) {
      dtype_flag = 0;
  } else if(tensor_dtype == ge::DT_FLOAT) {
      dtype_flag = 1;
  }
  if(other_size == 1) {
    mode = 0;
  } else if(other_size == input_size) {
    mode = 1;
  } else {
    mode = 2;
  }
  tiling.set_data_type(dtype_flag);
  tiling.set_mode(mode);
  tiling.set_input_size(other_size);
  tiling.set_input_shape(arrInput);
  tiling.set_other_shape(arrOther);
  tiling.set_output_shape(arrOutput);
  tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());
  context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());
//  std::cout << mode << " " << input_size << " " << other_size << " " << dtype_flag << std::endl;
  return ge::GRAPH_SUCCESS;
}
}


namespace ge {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    const gert::Shape* x1_shape = context->GetInputShape(0);
    gert::Shape* y_shape = context->GetOutputShape(0);
    *y_shape = *x1_shape;
    return GRAPH_SUCCESS;
}
}


namespace ops {
class Hypot : public OpDef {
public:
    explicit Hypot(const char* name) : OpDef(name)
    {
        this->Input("input")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("other")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("output")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});

        this->SetInferShape(ge::InferShape);

        this->AICore()
            .SetTiling(optiling::TilingFunc);
        this->AICore().AddConfig("ascend910b");

    }
};

OP_ADD(Hypot);
}
