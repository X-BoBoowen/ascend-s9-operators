
#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(HypotTilingData)
  TILING_DATA_FIELD_DEF(uint32_t, data_type); // 0-fp16 1-fp32 2-bf16
  TILING_DATA_FIELD_DEF(uint32_t, mode); // 1 for no broadcast, 0 for scalar, 2 for broadcast
  TILING_DATA_FIELD_DEF(uint32_t, input_size); 
  TILING_DATA_FIELD_DEF_ARR(uint32_t, 8, input_shape);
  TILING_DATA_FIELD_DEF_ARR(uint32_t, 8, other_shape);
  TILING_DATA_FIELD_DEF_ARR(uint32_t, 8, output_shape);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(Hypot, HypotTilingData)
}

