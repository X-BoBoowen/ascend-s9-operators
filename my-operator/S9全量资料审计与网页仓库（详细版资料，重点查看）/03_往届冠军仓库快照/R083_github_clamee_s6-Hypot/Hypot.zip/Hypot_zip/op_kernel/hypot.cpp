#include "kernel_operator.h"

#define MSB_MASK_32 (0x80000000)
#define INV_MSB_MASK_16 (0x7FFF)

using namespace AscendC;
constexpr int32_t BUFFER_NUM = 2;
constexpr int32_t threshold = 204800;
// constexpr int32_t chunksize = 4096;

__aicore__ inline int align_to(int a, int b) {
    return (a + b - 1) / b * b;
}

template<typename T>
class KernelCopysign {
public:
    __aicore__ inline KernelCopysign() {}  
    __aicore__ inline void Init(GM_ADDR input, GM_ADDR other, GM_ADDR output, int mode)
    {
        inputGm.SetGlobalBuffer((__gm__ T *)input);
        otherGm.SetGlobalBuffer((__gm__ T *)other);
        outputGm.SetGlobalBuffer((__gm__ T *)output);
        pipe.InitBuffer(inQueueA, BUFFER_NUM, chunksize * sizeof(T));
        pipe.InitBuffer(inQueueB, BUFFER_NUM, chunksize * sizeof(T));
        pipe.InitBuffer(outQueueC, BUFFER_NUM, chunksize * sizeof(T));
//        pipe.InitBuffer(workQueue1, BUFFER_NUM, chunksize * sizeof(T)); 
//        pipe.InitBuffer(workQueue2, BUFFER_NUM, chunksize * sizeof(T)); 
//	if(std::is_same<T, bfloat16_t>::value)
	{
	    pipe.InitBuffer(tmp1, chunksize * sizeof(float)); 
	    pipe.InitBuffer(tmp2, chunksize * sizeof(float));
	}
//	if(mode == 2) {
//	    pipe.InitBuffer(inQueueC, BUFFER_NUM, chunksize * sizeof(float));
//	}
        this->mode = mode;
	this->alignNum = 32/sizeof(T);
//        Prepare();
        // DumpTensor(inputGm, 0, 16);
    }
    __aicore__ inline void Process(int offsetA, int offsetB, int offsetC, int size)
    {
        // DumpTensor(inputGm[32], 0, 16);
        // DumpTensor(otherGm[32], 1, 16);
        int loop = (size + chunksize - 1) / chunksize;
        int tile = size % chunksize;
        tile = tile == 0 ? chunksize : tile;
        if(mode == 1) {
            for(int i = 0; i != loop - 1; i++) {
                CopyInMode1(offsetA + i * chunksize, offsetB + i * chunksize, chunksize);
                ComputeMode1(chunksize);
                CopyOut(offsetA + i * chunksize, chunksize);
            }
            CopyInMode1(offsetA + (loop - 1) * chunksize, offsetB + (loop - 1) * chunksize, align_to(tile, 16));
            ComputeMode1(align_to(tile, 16));
            if(tile % 16) {
                CopyOutPad(offsetA + (loop - 1) * chunksize, tile);
            } else {
                CopyOut(offsetA + (loop - 1) * chunksize, tile);
            }
        } else {
            T scalar = otherGm(offsetB);
            for(int i = 0; i != loop - 1; i++) {
                CopyInMode2(offsetA + i * chunksize, chunksize);
                ComputeMode2(chunksize, scalar);
                CopyOut(offsetA + i * chunksize, chunksize);
            }
            CopyInMode2(offsetA + (loop - 1) * chunksize, align_to(tile, 16));
            ComputeMode2(align_to(tile, 16), scalar);
            if(tile % 16) {
                CopyOutPad(offsetA + (loop - 1) * chunksize, tile);
            } else {
                CopyOut(offsetA + (loop - 1) * chunksize, tile);
            }
        }
        // DumpTensor(outputGm[32], 2, 16);
    }
    __aicore__ inline void Process2(int offsetA, int offsetB, int offsetC, int size, int repeat)
{
	// DumpTensor(inputGm[32], 0, 16);
	// DumpTensor(otherGm[32], 1, 16);
	int loop = (size + chunksize - 1) / chunksize;
	int tile = size % chunksize;
	tile = tile == 0 ? chunksize : tile;
	int mblock=1;
	if(loop==1)
	    mblock=chunksize/align_to(size,alignNum);
	if(mblock==1)
	{
		/*int nsize=align_to(tile,16);
                CopyInMode3(offsetA + (loop - 1) * chunksize, nsize);
                Prepare(nsize);
                for(int j = 0; j != repeat;j++)
                {
                        CopyInMode2(offsetA + (loop - 1) * chunksize + j * size, nsize);
                        ComputeMode3(nsize);
                        if(tile % 16) {
                                CopyOutPad(offsetA + (loop - 1) * chunksize + j * size, tile);
                        } else {
                                CopyOut(offsetA + (loop - 1) * chunksize + j * size, tile);
                        }
                }
		Release();*/
		for(int i = 0; i != loop - 1; i++) {
			//prepare
			CopyInMode3(offsetB + i * chunksize, chunksize);
			//Prepare(chunksize);
#define len chunksize
			LocalTensor<T> bLocal = inQueueB.DeQue<T>();
			LocalTensor<float> b;
			if(std::is_same<T, bfloat16_t>::value)
			{
				b=tmp2.Get<float>();
				Cast(b,bLocal,AscendC::RoundMode::CAST_NONE,len);
            			Mul(b,b,b,len);
				inQueueB.FreeTensor(bLocal);
			}
			else
			{
//				b=bLocal;
				Mul(bLocal,bLocal,bLocal,len);
			}
			for(int j = 0; j != repeat; j++) {
				CopyInMode2(offsetA + i * chunksize + j * size, chunksize);
				//ComputeMode3(chunksize);
				{
        if(std::is_same<T, bfloat16_t>::value) {
            LocalTensor<T> aLocal = inQueueA.DeQue<T>();
 //           LocalTensor<T> b = inQueueB.DeQue<T>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
            auto a=tmp1.Get<float>();

            Cast(a,aLocal,AscendC::RoundMode::CAST_NONE,len);

            Mul(a,a,a,len);
            Add(a,a,b,len);
            Sqrt(a,a,len);

            Cast(cLocal,a,AscendC::RoundMode::CAST_RINT,len);

            outQueueC.EnQue(cLocal);
            inQueueA.FreeTensor(aLocal);
        }
        else if(sizeof(T) == 4) {
            LocalTensor<T> aLocal = inQueueA.DeQue<T>();
//            LocalTensor<float> bLocal = inQueueB.DeQue<float>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
            Mul(aLocal,aLocal,aLocal,len);
//            Mul(bLocal,bLocal,bLocal,len);
            Add(cLocal,aLocal,bLocal,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
//            inQueueB.EnQue(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
        else {
            LocalTensor<T> aLocal = inQueueA.DeQue<T>();
//            LocalTensor<half> bLocal = inQueueB.DeQue<half>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
            Mul(aLocal,aLocal,aLocal,len);
//            Mul(bLocal,bLocal,bLocal,len);
            Add(cLocal,aLocal,bLocal,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
//            inQueueB.EnQue(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
#undef len		
				}

				CopyOut(offsetA + i * chunksize + j * size, chunksize);
			}
			//release
//			Release();
			if(!(std::is_same<T, bfloat16_t>::value))
				inQueueB.FreeTensor(bLocal);
		}
		int nsize=align_to(tile,16);
		CopyInMode3(offsetB + (loop - 1) * chunksize, nsize);
		//Prepare(nsize);
#define len nsize
                        LocalTensor<T> bLocal = inQueueB.DeQue<T>();
                        LocalTensor<float> b;
                        if(std::is_same<T, bfloat16_t>::value)
                        {
                                b=tmp2.Get<float>();
                                Cast(b,bLocal,AscendC::RoundMode::CAST_NONE,len);
                                Mul(b,b,b,len);
				inQueueB.FreeTensor(bLocal);
                        }
                        else
                        {
//                              b=bLocal;
                                Mul(bLocal,bLocal,bLocal,len);
                        }
		for(int j = 0; j != repeat;j++)
		{
			CopyInMode2(offsetA + (loop - 1) * chunksize + j * size, nsize);
//			ComputeMode3(nsize);
        if(std::is_same<T, bfloat16_t>::value) {
            LocalTensor<T> aLocal = inQueueA.DeQue<T>();
 //           LocalTensor<T> b = inQueueB.DeQue<T>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
            auto a=tmp1.Get<float>();

            Cast(a,aLocal,AscendC::RoundMode::CAST_NONE,len);

            Mul(a,a,a,len);
            Add(a,a,b,len);
            Sqrt(a,a,len);

            Cast(cLocal,a,AscendC::RoundMode::CAST_RINT,len);

            outQueueC.EnQue(cLocal);
            inQueueA.FreeTensor(aLocal);
        }
        else if(sizeof(T) == 4) {
            LocalTensor<T> aLocal = inQueueA.DeQue<T>();
//            LocalTensor<float> bLocal = inQueueB.DeQue<float>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
            Mul(aLocal,aLocal,aLocal,len);
//            Mul(bLocal,bLocal,bLocal,len);
            Add(cLocal,aLocal,bLocal,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
//            inQueueB.EnQue(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
        else {
            LocalTensor<T> aLocal = inQueueA.DeQue<T>();
//            LocalTensor<half> bLocal = inQueueB.DeQue<half>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
            Mul(aLocal,aLocal,aLocal,len);
//            Mul(bLocal,bLocal,bLocal,len);
            Add(cLocal,aLocal,bLocal,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
//            inQueueB.EnQue(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
#undef len
			if(tile % 16) {
				CopyOutPad(offsetA + (loop - 1) * chunksize + j * size, tile);
			} else {
				CopyOut(offsetA + (loop - 1) * chunksize + j * size, tile);
			}
		}
		//Release();
		if(!(std::is_same<T, bfloat16_t>::value))
			inQueueB.FreeTensor(bLocal);
	}
	else
	{
		int nlen=align_to(size,alignNum);
                CopyInMode3(offsetB, nlen);
                Prepare2(nlen, mblock);
                for(int j = 0; j < repeat;j+=mblock)
                {
			int msize=min(mblock,repeat-j);
                        CopyInMode5(offsetA + j * size, size, msize);
                        ComputeMode3(nlen * msize);
                        CopyOutPad2(offsetA + j * size, size, msize);
                }
                Release();
	}
}
/*    __aicore__ inline void Release()
    {
        LocalTensor<T> workLocal1 = workQueue1.DeQue<T>();
        LocalTensor<T> workLocal2 = workQueue2.DeQue<T>();
        workQueue1.FreeTensor(workLocal1);
        workQueue2.FreeTensor(workLocal2);
    }
*/
private:
    __aicore__ inline void Prepare(int len)
    {
/*        if(sizeof(T) == 4) {
            LocalTensor<uint32_t> workLocal1 = workQueue1.AllocTensor<uint32_t>();
            LocalTensor<uint32_t> workLocal2 = workQueue2.AllocTensor<uint32_t>();
            uint32_t a = ~MSB_MASK_32;
            uint32_t b = MSB_MASK_32;
            Duplicate(workLocal1, a, chunksize);
            Duplicate(workLocal2, b, chunksize);
            workQueue1.EnQue(workLocal1);
            workQueue2.EnQue(workLocal2);
        } else {
            LocalTensor<uint16_t> workLocal1 = workQueue1.AllocTensor<uint16_t>();
            LocalTensor<uint16_t> workLocal2 = workQueue2.AllocTensor<uint16_t>();
            uint16_t a = INV_MSB_MASK_16;
            uint16_t b = ~INV_MSB_MASK_16;
            Duplicate(workLocal1, a, chunksize);
            Duplicate(workLocal2, b, chunksize);
            workQueue1.EnQue(workLocal1);
            workQueue2.EnQue(workLocal2);
        }*/
	LocalTensor<T> aLocal = inQueueB.DeQue<T>();
	if(std::is_same<T, bfloat16_t>::value) {
//		auto a=tmp1.Get<float>();

//		Cast(a,aLocal,AscendC::RoundMode::CAST_NONE,len);

//		Mul(a,a,a,len);

//		Cast(aLocal,a,AscendC::RoundMode::CAST_RINT,len);
	}
	else {
		Mul(aLocal,aLocal,aLocal,len);
	}
	inQueueB.EnQue(aLocal);
    }
    __aicore__ inline void Prepare2(int len, int mblock)
    {
/*        if(sizeof(T) == 4) {
            LocalTensor<uint32_t> workLocal1 = workQueue1.AllocTensor<uint32_t>();
            LocalTensor<uint32_t> workLocal2 = workQueue2.AllocTensor<uint32_t>();
            uint32_t a = ~MSB_MASK_32;
            uint32_t b = MSB_MASK_32;
            Duplicate(workLocal1, a, chunksize);
            Duplicate(workLocal2, b, chunksize);
            workQueue1.EnQue(workLocal1);
            workQueue2.EnQue(workLocal2);
        } else {
            LocalTensor<uint16_t> workLocal1 = workQueue1.AllocTensor<uint16_t>();
            LocalTensor<uint16_t> workLocal2 = workQueue2.AllocTensor<uint16_t>();
            uint16_t a = INV_MSB_MASK_16;
            uint16_t b = ~INV_MSB_MASK_16;
            Duplicate(workLocal1, a, chunksize);
            Duplicate(workLocal2, b, chunksize);
            workQueue1.EnQue(workLocal1);
            workQueue2.EnQue(workLocal2);
        }*/
        if(std::is_same<T, bfloat16_t>::value) {
	LocalTensor<half> aLocal = inQueueB.DeQue<half>();
//        Mul(aLocal,aLocal,aLocal,len);
//      uint32_t Shape1[2]={1,len};
//      uint32_t Shape2[2]={mblock,len};
        uint32_t Shape1[2] = {1, static_cast<uint32_t>(len)};
        uint32_t Shape2[2] = {static_cast<uint32_t>(mblock), static_cast<uint32_t>(len)};
        dstShape_ = Shape2;
        srcShape_ = Shape1;
        auto dstLocal=tmp1.Get<half>();
        DataCopy(dstLocal, aLocal, len);
	inQueueB.FreeTensor(aLocal);
	LocalTensor<half> bLocal = inQueueB.AllocTensor<half>();
        AscendC::Broadcast<half, 2, 0>(bLocal, dstLocal, dstShape_, srcShape_);
//      inQueueA.FreeTensor(aLocal);
        inQueueB.EnQue(bLocal);
//              auto a=tmp1.Get<float>();

//              Cast(a,aLocal,AscendC::RoundMode::CAST_NONE,len);

//              Mul(a,a,a,len);

//              Cast(aLocal,a,AscendC::RoundMode::CAST_RINT,len);
        }
        else {
	LocalTensor<T> aLocal = inQueueB.DeQue<T>();
        Mul(aLocal,aLocal,aLocal,len);
//	uint32_t Shape1[2]={1,len};
//	uint32_t Shape2[2]={mblock,len};
	uint32_t Shape1[2] = {1, static_cast<uint32_t>(len)};
	uint32_t Shape2[2] = {static_cast<uint32_t>(mblock), static_cast<uint32_t>(len)};
	dstShape_ = Shape2;
        srcShape_ = Shape1;
	auto dstLocal=tmp1.Get<T>();
	DataCopy(dstLocal, aLocal, len);
	inQueueB.FreeTensor(aLocal);
        LocalTensor<T> bLocal = inQueueB.AllocTensor<T>();
	AscendC::Broadcast<T, 2, 0>(bLocal, dstLocal, dstShape_, srcShape_);
//	inQueueA.FreeTensor(aLocal);
        inQueueB.EnQue(bLocal);
	}
    }
    __aicore__ inline void Release()
    {
        LocalTensor<T> bLocal = inQueueB.DeQue<T>();
        inQueueB.FreeTensor(bLocal);
    }
    __aicore__ inline void CopyInMode1(int offsetA, int offsetB, int len)
    {
        LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
        LocalTensor<T> bLocal = inQueueB.AllocTensor<T>();
        DataCopy(aLocal, inputGm[offsetA], len);
        DataCopy(bLocal, otherGm[offsetB], len);
        inQueueA.EnQue(aLocal);
        inQueueB.EnQue(bLocal);
    }
    __aicore__ inline void CopyInMode2(int offsetA, int len)
    {
        LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
        DataCopy(aLocal, inputGm[offsetA], len);
        inQueueA.EnQue(aLocal);
    }
    __aicore__ inline void CopyInMode3(int offsetB, int len)
    {
        LocalTensor<T> bLocal = inQueueB.AllocTensor<T>();
        DataCopy(bLocal, otherGm[offsetB], len);
        inQueueB.EnQue(bLocal);
    }
    __aicore__ inline void CopyInMode4(int offsetB, int len)
    {
        LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
        DataCopy(aLocal, otherGm[offsetB], len);
        inQueueA.EnQue(aLocal);
    }
    __aicore__ inline void CopyInMode5(int offset, int len, int repeat) {
		LocalTensor<T> x1 = inQueueA.AllocTensor<T>();
		DataCopyExtParams copyParamsX;
		copyParamsX.blockCount = repeat;
		copyParamsX.blockLen = len * sizeof(T);
		copyParamsX.srcStride = 0;
		copyParamsX.dstStride = 0;
		DataCopyPadExtParams<T> padParams{false, 0, 0, 0};
		DataCopyPad(x1, inputGm[offset], copyParamsX, padParams);
		inQueueA.EnQue(x1);
    }
    __aicore__ inline void ComputeMode1(int len)
    {
        //int type = sizeof(T) / 2;
	if(std::is_same<T, bfloat16_t>::value) {
	    LocalTensor<T> a = inQueueA.DeQue<T>();
            LocalTensor<T> b = inQueueB.DeQue<T>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
	    auto aLocal=tmp1.Get<float>();
	    auto bLocal=tmp2.Get<float>();
	    
	    Cast(aLocal,a,AscendC::RoundMode::CAST_NONE,len);
	    Cast(bLocal,b,AscendC::RoundMode::CAST_NONE,len);

	    Mul(aLocal,aLocal,aLocal,len);
            Mul(bLocal,bLocal,bLocal,len);
            Add(aLocal,aLocal,bLocal,len);
            Sqrt(aLocal,aLocal,len);
	    
            Cast(cLocal,aLocal,AscendC::RoundMode::CAST_RINT,len);

	    outQueueC.EnQue(cLocal);
            inQueueB.FreeTensor(b);
            inQueueA.FreeTensor(a);
	}
	else if(sizeof(T) == 4) {
            LocalTensor<float> aLocal = inQueueA.DeQue<float>();
            LocalTensor<float> bLocal = inQueueB.DeQue<float>();
            LocalTensor<float> cLocal = outQueueC.AllocTensor<float>();
	    Mul(aLocal,aLocal,aLocal,len);
	    Mul(bLocal,bLocal,bLocal,len);
	    Add(cLocal,aLocal,bLocal,len);
	    Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
            inQueueB.FreeTensor(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
	else {
            LocalTensor<half> aLocal = inQueueA.DeQue<half>();
            LocalTensor<half> bLocal = inQueueB.DeQue<half>();
            LocalTensor<half> cLocal = outQueueC.AllocTensor<half>();
            Mul(aLocal,aLocal,aLocal,len);
            Mul(bLocal,bLocal,bLocal,len);
            Add(cLocal,aLocal,bLocal,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
            inQueueB.FreeTensor(bLocal);
            inQueueA.FreeTensor(aLocal);  
        }
    }
    __aicore__ inline void ComputeMode2(int len, T scalar)
    {
	float nscalar;
	if(std::is_same<T, bfloat16_t>::value)
	    nscalar=ToFloat(scalar);
	else nscalar=(float)scalar;
	nscalar=nscalar*nscalar;
	if(sizeof(T) == 4) {
            LocalTensor<float> aLocal = inQueueA.DeQue<float>();
            LocalTensor<float> bLocal = inQueueB.DeQue<float>();
            LocalTensor<float> cLocal = outQueueC.AllocTensor<float>();
            Mul(aLocal,aLocal,aLocal,len);
            //Mul(bLocal,bLocal,bLocal,len);
            Adds(cLocal,aLocal,(float)nscalar,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
            inQueueB.FreeTensor(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
        else {
            LocalTensor<half> aLocal = inQueueA.DeQue<half>();
            LocalTensor<half> bLocal = inQueueB.DeQue<half>();
            LocalTensor<half> cLocal = outQueueC.AllocTensor<half>();
            Mul(aLocal,aLocal,aLocal,len);
            //Mul(bLocal,bLocal,bLocal,len);
            Adds(cLocal,aLocal,(half)nscalar,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
            inQueueB.FreeTensor(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
    }
     __aicore__ inline void ComputeMode3(int len)
    {
	if(std::is_same<T, bfloat16_t>::value) {
            LocalTensor<T> a = inQueueA.DeQue<T>();
            LocalTensor<T> b = inQueueB.DeQue<T>();
            LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
            auto aLocal=tmp1.Get<float>(); 
            auto bLocal=tmp2.Get<float>();

            Cast(aLocal,a,AscendC::RoundMode::CAST_NONE,len);
            Cast(bLocal,b,AscendC::RoundMode::CAST_NONE,len);

            Mul(aLocal,aLocal,aLocal,len);
            Mul(bLocal,bLocal,bLocal,len);
            Add(aLocal,aLocal,bLocal,len);
            Sqrt(aLocal,aLocal,len);

            Cast(cLocal,aLocal,AscendC::RoundMode::CAST_RINT,len);

            outQueueC.EnQue(cLocal);
            inQueueB.EnQue(b);
            inQueueA.FreeTensor(a);
        }
        else if(sizeof(T) == 4) {
            LocalTensor<float> aLocal = inQueueA.DeQue<float>();
            LocalTensor<float> bLocal = inQueueB.DeQue<float>();
            LocalTensor<float> cLocal = outQueueC.AllocTensor<float>();
            Mul(aLocal,aLocal,aLocal,len);
//            Mul(bLocal,bLocal,bLocal,len);
            Add(cLocal,aLocal,bLocal,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal);
            inQueueB.EnQue(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
        else {
            LocalTensor<half> aLocal = inQueueA.DeQue<half>();
            LocalTensor<half> bLocal = inQueueB.DeQue<half>();
            LocalTensor<half> cLocal = outQueueC.AllocTensor<half>();
            Mul(aLocal,aLocal,aLocal,len);
//            Mul(bLocal,bLocal,bLocal,len);
            Add(cLocal,aLocal,bLocal,len);
            Sqrt(cLocal,cLocal,len);

            outQueueC.EnQue(cLocal); 
            inQueueB.EnQue(bLocal);
            inQueueA.FreeTensor(aLocal);
        }
    }
    __aicore__ inline void CopyOut(int offsetC, int len)
    {
        LocalTensor<T> cLocal = outQueueC.DeQue<T>();
        // PRINTF("%d %d\n", offsetC, len);
        // DumpTensor(cLocal[32], 8, 16);
        DataCopy(outputGm[offsetC], cLocal, len);
        outQueueC.FreeTensor(cLocal);
    }
    __aicore__ inline void CopyOutPad(int offsetC, int len)
    {
        DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        LocalTensor<T> cLocal = outQueueC.DeQue<T>();
        DataCopyPad(outputGm[offsetC], cLocal, copyParams);
        outQueueC.FreeTensor(cLocal);
    }
    __aicore__ inline void CopyOutPad2(int offsetC, int len, int repeat)
    {
        DataCopyExtParams copyParams{static_cast<uint16_t>(repeat), static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        LocalTensor<T> cLocal = outQueueC.DeQue<T>();
        DataCopyPad(outputGm[offsetC], cLocal, copyParams);
        outQueueC.FreeTensor(cLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, 1> inQueueA;
    TQue<QuePosition::VECIN, 1> inQueueB;
    TBuf<TPosition::VECCALC> tmp1;
    TBuf<TPosition::VECCALC> tmp2;
    const uint32_t *dstShape_{nullptr};
    const uint32_t *srcShape_{nullptr};
//    TQue<QuePosition::VECIN, 1> inQueueC;
//    TQue<QuePosition::VECIN, 1> workQueue2;
    TQue<QuePosition::VECOUT, 1> outQueueC;
    GlobalTensor<T> inputGm;
    GlobalTensor<T> otherGm;
    GlobalTensor<T> outputGm;
    int mode, alignNum;
    int chunksize = sizeof(T) == 2 ? 9728 : 4864;
};

extern "C" __global__ __aicore__ void hypot(GM_ADDR other, GM_ADDR input, GM_ADDR output, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    const uint32_t* input_shape = tiling_data.other_shape;
    const uint32_t* other_shape = tiling_data.input_shape;
    // const uint32_t* output = tiling_data.output_shape;
    const uint32_t data_type = tiling_data.data_type;
    const uint32_t mode = tiling_data.mode;
    const uint32_t input_size = tiling_data.input_size;
    int blockIdx = GetBlockIdx();
    int blockDim = GetBlockNum();
    int cacheline = data_type == 1 ? 64 : 128;
    if(mode == 1 || mode == 0) {
        int chunks = (input_size + cacheline - 1) / cacheline;
        int base_chunks = chunks / blockDim;
        int tile_chunks = chunks % blockDim;
        int start = (base_chunks * blockIdx + min(blockIdx, tile_chunks)) * cacheline;
        int len = min(int(input_size) - start, (base_chunks + (blockIdx < tile_chunks)) * cacheline);
        if(len <= 0) return;
        if(data_type == 0) {
            KernelCopysign<half> op;
            op.Init(input, other, output, mode);
            op.Process(start, start * mode, start, len);
        //    op.Release();
        } 
	else if(data_type == 2) {
	    KernelCopysign<bfloat16_t> op;
            op.Init(input, other, output, mode);
            op.Process(start, start * mode, start, len);
        //    op.Release();
	}
	else if(data_type == 1) {
            GlobalTensor<int32_t> workGm;
            workGm.SetGlobalBuffer((__gm__ int32_t *)workspace);
            if(workGm(0)%2 && len > threshold) 
            {
                KernelCopysign<float> op;
                op.Init(input, other, output, mode);
                // int loop = len / threshold;
                // for(int i = loop; i != 0; i--) {
                //     op.Process(start+len-i*threshold, start * mode+len-i*threshold, start+len-i*threshold, threshold);
                // }
                // if(len % threshold)
                //     op.Process(start, start * mode, start, len - loop * threshold);
                op.Process(start+len-threshold, start * mode+len-threshold, start+len-threshold, threshold);
                op.Process(start, start * mode, start, len - threshold);
         //       op.Release();
            } else
            {
                KernelCopysign<float> op;
                op.Init(input, other, output, mode);
                op.Process(start, start * mode, start, len);
        //        op.Release();
            }
            if(blockIdx == 0) workGm(0) += 1;
        } else {
            // KernelCopysign<bfloat16_t> op;
            // op.Init(input, other, output, mode);
            // op.Process(start, start * mode, start, len);
        }
    } else {
        // 处理广播情况
        int input_dims = input_shape[0];
        int other_dims = other_shape[0];

        uint32_t input_total = input_size;

        uint32_t continuous_input_len = 1;
//	uint32_t repeat = 1;
        bool use_scalar_mode = false;

        // 最后一维分析
        uint32_t last_input_dim = input_shape[input_dims];
        uint32_t last_other_dim = (other_dims > 0) ? other_shape[other_dims] : 1;

        if(last_other_dim == 1) {
            // other最后一维是1，标量模式
            use_scalar_mode = true;
            continuous_input_len = last_input_dim;
        } else if(last_other_dim == last_input_dim) {
            // 最后一维匹配，向量模式
            use_scalar_mode = false;
            continuous_input_len = last_input_dim;
            for(int dim = input_dims - 1; dim >= 1; dim--) {
                uint32_t input_dim_size = input_shape[dim];
                int other_dim_idx = dim - (input_dims - other_dims);
                uint32_t other_dim_size = (other_dim_idx >= 1) ? other_shape[other_dim_idx] : 1;

                if(other_dim_size == input_dim_size) {
                    continuous_input_len *= input_dim_size;
                } else {
//		    repeat = input_dim_size;
                    break; // 不匹配就停止
                }
            }
        } else {
            // 不兼容，fallback
            continuous_input_len = 1;
        }

        // 计算需要外层循环处理的段数
        uint32_t outer_segments = input_total / continuous_input_len;

        // 分块处理
        uint32_t segments_per_block = (outer_segments + blockDim - 1) / blockDim;
        uint32_t start_segment = blockIdx * segments_per_block;
        uint32_t end_segment = min(outer_segments, start_segment + segments_per_block);

        if(start_segment >= outer_segments) return;

        int process_mode = use_scalar_mode ? 0 : 1;
        if(data_type == 0) {
            KernelCopysign<half> op;
            op.Init(input, other, output, process_mode);
            for(uint32_t seg = start_segment; seg < end_segment; seg++) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                // 将input的线性位置转换为多维坐标
                uint32_t coords[10]; // 假设最多10维
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                // 根据坐标和广播规则计算other_offset
                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0; // 广播维度，坐标为0
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }

                op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            }
      //      op.Release();
        }
	else if(data_type == 2) {
	    KernelCopysign<bfloat16_t> op;
            op.Init(input, other, output, process_mode);/*
            for(uint32_t seg = start_segment; seg < end_segment; seg++) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                // 将input的线性位置转换为多维坐标
                uint32_t coords[10]; // 假设最多10维
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                // 根据坐标和广播规则计算other_offset
                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0; // 广播维度，坐标为0
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }

                op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            }*/
	    uint32_t repeat = 1;
            for(uint32_t seg = start_segment; seg < end_segment; seg+=repeat) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑 (同上)
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                uint32_t coords[10];
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0;
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }
                uint32_t Input_offset=input_offset,Other_offset=other_offset;
                repeat=1;
                while(seg+repeat<end_segment)
                {
                input_offset = (seg+repeat) * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑 (同上)
                other_offset = 0;
                input_start_pos = (seg+repeat) * continuous_input_len;
                temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0;
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }
                if(Other_offset!=other_offset)break;
                repeat++;
                }
                // PRINTF("%d %d %d %d\n",input_offset, other_offset,continuous_input_len, process_mode);
                op.Process2(Input_offset, Other_offset, Input_offset, continuous_input_len, repeat);
            }
	}
	else if(data_type == 1) {
            KernelCopysign<float> op;
            op.Init(input, other, output, process_mode);
	    uint32_t repeat = 1;
            for(uint32_t seg = start_segment; seg < end_segment; seg+=repeat) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑 (同上)
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                uint32_t coords[10];
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0;
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }
		uint32_t Input_offset=input_offset,Other_offset=other_offset;
		repeat=1;
		while(seg+repeat<end_segment)
		{
		input_offset = (seg+repeat) * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑 (同上)
                other_offset = 0;
                input_start_pos = (seg+repeat) * continuous_input_len;
                temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0;
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }
		if(Other_offset!=other_offset)break;
		repeat++;
		}
                // PRINTF("%d %d %d %d\n",input_offset, other_offset,continuous_input_len, process_mode);
                op.Process2(Input_offset, Other_offset, Input_offset, continuous_input_len, repeat);
            }
    //        op.Release();
        }
    }
}
