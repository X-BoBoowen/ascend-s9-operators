
#include "pows_tiling.h"
#include "register/op_def_registry.h"

#include "tiling/platform/platform_ascendc.h"
#include <iostream>
#include <cmath>
namespace optiling {
const uint32_t BLOCK_DIM = 1;
const uint32_t BLOCK_SIZE = 64;

static ge::graphStatus TilingFunc(gert::TilingContext* context)
{
//系统信息
    uint64_t ubSize;//一个核上的UB大小 910b4 196352 Byte 310b1 253952
    auto ascendcPlatform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    ascendcPlatform.GetCoreMemSize(platform_ascendc::CoreMemType::UB, ubSize);
    auto coreNumAiv=ascendcPlatform.GetCoreNumAiv();
    auto coreNumAic=ascendcPlatform.GetCoreNumAiv();
    printf("coreNumAiv%d coreNumAic%d UB_Size %ld \n",coreNumAiv,coreNumAic,ubSize);


// tiling算法开始
    PowsTilingData tiling;
   
    uint32_t x1Size = context->GetInputShape(0)->GetStorageShape().GetShapeSize();
    uint32_t x2Size = context->GetInputShape(1)->GetStorageShape().GetShapeSize();
    uint32_t ySize = context->GetOutputShape(0)->GetStorageShape().GetShapeSize();

    uint32_t inputNum = context->GetOutputShape(0)->GetStorageShape().GetShapeSize(); //输入数量

    uint32_t inputBytes = GetSizeByDataType(context->GetInputDesc(0)->GetDataType()); //输入类型
    uint32_t inputLength = inputBytes * inputNum; //输入长度
    printf("inputbytes:%d\n",inputBytes);
    //可使用的ub空间 输入3输出1，手动考虑双缓存
    uint32_t ubDataNumber = 3*2+2*2;
    if(inputBytes == 2)
        ubDataNumber = 3*2+2*4;// Todo 弄懂这里是什么

    else if(inputBytes == 4)
        ubDataNumber = 3*4;// ?? 不懂


    // The number of 32B data blocks that can be used for each data. DOUBLE BUFFER is already counted here
    uint32_t tileBlockNum = (ubSize / BLOCK_SIZE) / ubDataNumber; //每个ub段可用的空间块数
    uint32_t tileDataNum = (tileBlockNum * BLOCK_SIZE) / inputBytes; //每次处理的数据数量

    // Input data for 32B alignment
    uint32_t inputLengthAlgin32 = (((inputLength + BLOCK_SIZE - 1) / BLOCK_SIZE) * BLOCK_SIZE); //输入长度 对齐处理
    // There is at least 32B of data on each core, satisfying several settings for several cores. The maximum number of audits is the actual number of audits
    uint32_t everyCoreInputBlockNum = inputLengthAlgin32 / BLOCK_SIZE;// 输入数据需要多少空间块
    // uint32_t tailBlockNum = (inputLengthAlgin32 / BLOCK_SIZE) % aivNum;

    //  chunks are calculated and sliced several times using the number of data on each core
    uint32_t CoreDataNum = everyCoreInputBlockNum * BLOCK_SIZE / inputBytes; //对齐空间后的输入数量
    uint32_t TileNum = everyCoreInputBlockNum / tileBlockNum;
    uint32_t finalTileNum = (everyCoreInputBlockNum % tileBlockNum) == 0 ? TileNum : TileNum + 1; //需要循环处理几次
    // Tail block calculation for  chunks of data
    uint32_t TailDataNum = CoreDataNum - (tileDataNum * TileNum);
    TailDataNum = TailDataNum == 0 ? tileDataNum : TailDataNum; //最后一次需要处理的数据量
    TailDataNum = (((TailDataNum + BLOCK_SIZE - 1) / BLOCK_SIZE) * BLOCK_SIZE);
    
    tiling.set_CoreDataNum(CoreDataNum);  //对齐空间后的输入数量
    tiling.set_finalTileNum(finalTileNum);//需要循环处理几次
    tiling.set_tileDataNum(tileDataNum); //每次处理的数据量
    tiling.set_TailDataNum(TailDataNum); //最后一次需要处理的数据量

    printf("coreDataNum:%d\ntileNum:%d\ntileDataNum:%d\ntailDataNum:%d\n ",
        CoreDataNum, finalTileNum, tileDataNum, TailDataNum);

    if(x1Size==x2Size)
    {
        context->SetTilingKey(1);
    }
    else
    {
        context->SetTilingKey(2);
        tiling.set_x1Size(x1Size);
        tiling.set_x2Size(x2Size);

    }

    const gert::StorageShape* x1_shape = context->GetInputShape(0);
    int32_t data_sz = 1;
    for (int i = 0; i < x1_shape->GetStorageShape().GetDimNum(); i++)
        data_sz *= x1_shape->GetStorageShape().GetDim(i);
    tiling.set_size(data_sz);
    context->SetBlockDim(BLOCK_DIM);//设置核数
    tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());
    context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());

    return ge::GRAPH_SUCCESS;

}
}


namespace ge {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    const gert::Shape* x1_shape = context->GetInputShape(0);
    gert::Shape* y_shape = context->GetOutputShape(0);
    *y_shape = *x1_shape;
    return GRAPH_SUCCESS;
}
}


namespace ops {
class Pows : public OpDef {
public:
    explicit Pows(const char* name) : OpDef(name)
    {
        this->Input("x1")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("x2")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("y")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});

        this->SetInferShape(ge::InferShape);

        this->AICore()
            .SetTiling(optiling::TilingFunc);
        this->AICore().AddConfig("ascend310b");

    }
};

OP_ADD(Pows);
}
