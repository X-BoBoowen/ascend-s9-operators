#include "kernel_operator.h"
#include <type_traits>
#include <cmath>
using namespace AscendC;
constexpr int32_t BUFFER_NUM = 2;

template<typename TYPE_X1> class KernelPows {
    using T = TYPE_X1;
public:
    __aicore__ inline KernelPows() {}
    __aicore__ inline void Init(GM_ADDR x1, GM_ADDR x2, GM_ADDR y, 
                            uint32_t CoreDataNum, uint32_t finalTileNum, uint32_t tileDataNum, uint32_t TailDataNum) {
        //ASSERT(GetBlockNum() != 0 && "block dim can not be zero!");
        this->coreDataNum = CoreDataNum;
        this->tileNum = finalTileNum;
        this->tileDataNum = tileDataNum;
        this->tailDataNum = TailDataNum;

        // printf("coreDataNum:%d\ntileNum:%d\ntileDataNum:%d\ntailDataNum:%d\n ",
        //     this->coreDataNum, this->tileNum, this->tileDataNum, this->tailDataNum);
        // this->coreDataNum=8192;
        // this->tileNum=8;
        // this->tailDataNum=this->tileDataNum=1024;
        x1Gm.SetGlobalBuffer((__gm__ DTYPE_X1*)x1, this->coreDataNum);
        x2Gm.SetGlobalBuffer((__gm__ DTYPE_X2*)x2, this->coreDataNum);        
        yGm.SetGlobalBuffer((__gm__ DTYPE_Y*)y, this->coreDataNum);

        pipe.InitBuffer(inQueueX1, BUFFER_NUM, this->tileDataNum * sizeof(DTYPE_X1));
        pipe.InitBuffer(inQueueX2, BUFFER_NUM, this->tileDataNum * sizeof(DTYPE_X2));
        pipe.InitBuffer(outQueueY, BUFFER_NUM, this->tileDataNum * sizeof(DTYPE_Y));
        

        if constexpr (!std::is_same_v<T, float>)
        {
            pipe.InitBuffer(QueueTmpX1, this->tileDataNum * sizeof(float));
            pipe.InitBuffer(QueueTmpX2, this->tileDataNum * sizeof(float));
        }
        printf("Init fi\n");



    }

    __aicore__ inline void Process() {
        int32_t loopCount = this->tileNum;
        this->processDataNum = this->tileDataNum;
        for (int32_t i = 0; i < loopCount; i++) {
            if (i == this->tileNum - 1) {
              this->processDataNum = this->tailDataNum;
            }
            //printf("tileNum %d start\n",i);
            CopyIn(i);
            Compute(i);
            CopyOut(i);
            //printf("tileNum %d end\n",i);

        }
    }

private:
    __aicore__ inline void CopyIn(int32_t progress) {
        LocalTensor<DTYPE_X1> x1Local = inQueueX1.AllocTensor<DTYPE_X1>();
        LocalTensor<DTYPE_X2> x2Local = inQueueX2.AllocTensor<DTYPE_X2>();
        DataCopy(x1Local, x1Gm[progress * this->tileDataNum], this->processDataNum);
        DataCopy(x2Local, x2Gm[progress * this->tileDataNum], this->processDataNum);
        inQueueX1.EnQue(x1Local);
        inQueueX2.EnQue(x2Local);
    }

    __aicore__ inline void Compute(int32_t progress) {
        LocalTensor<DTYPE_X1> x1Local = inQueueX1.DeQue<DTYPE_X1>();
        LocalTensor<DTYPE_X2> x2Local = inQueueX2.DeQue<DTYPE_X2>();
        LocalTensor<DTYPE_Y> yLocal = outQueueY.AllocTensor<DTYPE_Y>();


        // 加精度转换的计算

        if constexpr (std::is_same_v<T, float>)
        {
            //不加精度转换的计算fp16//误差能到2e0
            // 计算 ln(a)
            Ln(x1Local, x1Local, tileDataNum);
            // 计算 b * ln(a)
            Mul(x1Local, x1Local, x2Local, tileDataNum);
            // 计算 exp(b * ln(a))
            Exp(yLocal, x1Local, tileDataNum);
        }
        else
        {
            auto tmpx1=QueueTmpX1.Get<float>();
            auto tmpx2=QueueTmpX2.Get<float>();
            Cast(tmpx1, x1Local, RoundMode::CAST_NONE, this->processDataNum);
            Cast(tmpx2, x2Local, RoundMode::CAST_NONE, this->processDataNum);
            Ln(tmpx1, tmpx1, tileDataNum);
            Mul(tmpx1, tmpx1, tmpx2, tileDataNum);
            Exp(tmpx2, tmpx1, tileDataNum);
            Cast(yLocal, tmpx2, RoundMode::CAST_ROUND, this->processDataNum);
        }

        // DumpTensor(x1Local,1 , 32);
        // DumpTensor(x2Local,2 , 32);
        // DumpTensor(yLocal ,3 , 32);

        inQueueX1.FreeTensor(x1Local);
        inQueueX2.FreeTensor(x2Local);
        outQueueY.EnQue(yLocal);

    }
    __aicore__ inline void CopyOut(int32_t progress) {
        LocalTensor<DTYPE_Y> yLocal = outQueueY.DeQue<DTYPE_Y>();
        DataCopy(yGm[progress * this->tileDataNum], yLocal, this->processDataNum);
        outQueueY.FreeTensor(yLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, BUFFER_NUM> inQueueX1, inQueueX2;
    TQue<QuePosition::VECOUT, BUFFER_NUM> outQueueY;
    TBuf<QuePosition::VECCALC> QueueTmp1, QueueTmpBit, QueueTmpX1, QueueTmpX2, QueueResult, Queuezero;

    GlobalTensor<DTYPE_X1> x1Gm;
    GlobalTensor<DTYPE_X2> x2Gm;
    GlobalTensor<DTYPE_Y> yGm;
    LocalTensor<half> zero;//暂时无用
    uint32_t coreDataNum;//核（core）的数据个数
    uint32_t tileNum;//几个tile
    uint32_t tileDataNum;//一个TILE的数据个数
    uint32_t tailDataNum;//尾tile的数据个数
    uint32_t processDataNum;//本个tile的数据个数,属于中间变量，不属于tile结构体

};

template<typename TYPE_X1> class KernelPowsBroadcast {
    using T = TYPE_X1;
public:
    __aicore__ inline KernelPowsBroadcast() {}
    __aicore__ inline void Init(GM_ADDR x1, GM_ADDR x2, GM_ADDR y, 
                            uint32_t CoreDataNum, uint32_t finalTileNum, uint32_t tileDataNum, uint32_t TailDataNum,uint32_t x1Size,uint32_t x2Size) {
        //ASSERT(GetBlockNum() != 0 && "block dim can not be zero!");
        this->coreDataNum = CoreDataNum;
        this->tileNum = finalTileNum;
        this->tileDataNum = tileDataNum;
        this->tailDataNum = TailDataNum;

        this->x1Size=x1Size;
        this->x2Size=x2Size;


        // printf("coreDataNum:%d\ntileNum:%d\ntileDataNum:%d\ntailDataNum:%d\n ",
        //     this->coreDataNum, this->tileNum, this->tileDataNum, this->tailDataNum);
        x1Gm.SetGlobalBuffer((__gm__ DTYPE_X1*)x1, this->coreDataNum);
        x2Gm.SetGlobalBuffer((__gm__ DTYPE_X2*)x2, this->coreDataNum);        
        yGm.SetGlobalBuffer((__gm__ DTYPE_Y*)y, this->coreDataNum);

        pipe.InitBuffer(inQueueX1, BUFFER_NUM, this->tileDataNum * sizeof(DTYPE_X1));
        pipe.InitBuffer(inQueueX2, BUFFER_NUM, this->tileDataNum * sizeof(DTYPE_X2));
        pipe.InitBuffer(outQueueY, BUFFER_NUM, this->tileDataNum * sizeof(DTYPE_Y));
        

        if constexpr (!std::is_same_v<T, float>)
        {
            pipe.InitBuffer(QueueTmpX1, this->tileDataNum * sizeof(float));
            pipe.InitBuffer(QueueTmpX2, this->tileDataNum * sizeof(float));
        }


        //printf("Init fi\n");



    }

    __aicore__ inline void Process() {
        LocalTensor<DTYPE_X1> x1Local = inQueueX1.AllocTensor<DTYPE_X1>();
        LocalTensor<DTYPE_X2> x2Local = inQueueX2.AllocTensor<DTYPE_X2>();
        LocalTensor<DTYPE_Y> yLocal = outQueueY.AllocTensor<DTYPE_Y>();
        
        
        if constexpr (std::is_same_v<T, float>)
        {
            uint32_t loopCount=max(x1Size,x2Size);  
            for (size_t i = 0; i < loopCount; i++)
            {
                DTYPE_X1 x1 = x1Gm.GetValue(i%x1Size);
                DTYPE_X2 x2 = x2Gm.GetValue(i%x2Size);
                x1Local.SetValue(0, (DTYPE_Y)x1);
                x2Local.SetValue(0, (DTYPE_Y)x2);
                Ln(x1Local, x1Local, 1);
                Mul(x1Local, x1Local, x2Local, 1);
                Exp(yLocal, x1Local, 1);
                yGm.SetValue(i, (DTYPE_Y)yLocal.GetValue(0));

            }
        }
        else
        {
            uint32_t loopCount=max(x1Size,x2Size);  

            auto tmpx1=QueueTmpX1.Get<float>();
            auto tmpx2=QueueTmpX2.Get<float>();
            for (size_t i = 0; i < loopCount; i++)
            {
                DTYPE_X1 x1 = x1Gm.GetValue(i%x1Size);
                DTYPE_X2 x2 = x2Gm.GetValue(i%x2Size);
                x1Local.SetValue(0, (DTYPE_X1)x1);
                x2Local.SetValue(0, (DTYPE_X2)x2);
                Cast(tmpx1, x1Local, RoundMode::CAST_NONE, 1);
                Cast(tmpx2, x2Local, RoundMode::CAST_NONE, 1);
                Ln(tmpx1, tmpx1, 1);
                Mul(tmpx1, tmpx1, tmpx2, 1);
                Exp(tmpx2, tmpx1, 1);
                Cast(yLocal, tmpx2, RoundMode::CAST_ROUND, 1);
                yGm.SetValue(i, (DTYPE_Y)yLocal.GetValue(0));

            }
        }

    }

private:
    __aicore__ inline void CopyIn(int32_t progress) {
        LocalTensor<DTYPE_X1> x1Local = inQueueX1.AllocTensor<DTYPE_X1>();
        LocalTensor<DTYPE_X2> x2Local = inQueueX2.AllocTensor<DTYPE_X2>();
        DataCopy(x1Local, x1Gm[progress * this->tileDataNum], this->processDataNum);
        DataCopy(x2Local, x2Gm[progress * this->tileDataNum], this->processDataNum);
        inQueueX1.EnQue(x1Local);
        inQueueX2.EnQue(x2Local);
    }

    __aicore__ inline void Compute(int32_t progress) {
        LocalTensor<DTYPE_X1> x1Local = inQueueX1.DeQue<DTYPE_X1>();
        LocalTensor<DTYPE_X2> x2Local = inQueueX2.DeQue<DTYPE_X2>();
        LocalTensor<DTYPE_Y> yLocal = outQueueY.AllocTensor<DTYPE_Y>();
        // 加精度转换的计算

        if constexpr (std::is_same_v<T, float>)
        {
            //不加精度转换的计算fp16//误差能到2e0
            // 计算 ln(a)
            Ln(x1Local, x1Local, tileDataNum);
            // 计算 b * ln(a)
            Mul(x1Local, x1Local, x2Local, tileDataNum);
            // 计算 exp(b * ln(a))
            Exp(yLocal, x1Local, tileDataNum);
        }
        else
        {
            auto tmpx1=QueueTmpX1.Get<float>();
            auto tmpx2=QueueTmpX2.Get<float>();
            Cast(tmpx1, x1Local, RoundMode::CAST_NONE, this->processDataNum);
            Cast(tmpx2, x2Local, RoundMode::CAST_NONE, this->processDataNum);
            Ln(tmpx1, tmpx1, tileDataNum);
            Mul(tmpx1, tmpx1, tmpx2, tileDataNum);
            Exp(tmpx2, tmpx1, tileDataNum);
            Cast(yLocal, tmpx2, RoundMode::CAST_ROUND, this->processDataNum);
        }

        // DumpTensor(x1Local,1 , 32);
        // DumpTensor(x2Local,2 , 32);
        // DumpTensor(yLocal ,3 , 32);

        inQueueX1.FreeTensor(x1Local);
        inQueueX2.FreeTensor(x2Local);
        outQueueY.EnQue(yLocal);

    }
    __aicore__ inline void CopyOut(int32_t progress) {
        LocalTensor<DTYPE_Y> yLocal = outQueueY.DeQue<DTYPE_Y>();
        DataCopy(yGm[progress * this->tileDataNum], yLocal, this->processDataNum);
        outQueueY.FreeTensor(yLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, BUFFER_NUM> inQueueX1, inQueueX2;
    TQue<QuePosition::VECOUT, BUFFER_NUM> outQueueY;
    TBuf<QuePosition::VECCALC> QueueTmp1, QueueTmpBit, QueueTmpX1, QueueTmpX2, QueueResult, Queuezero;

    GlobalTensor<DTYPE_X1> x1Gm;
    GlobalTensor<DTYPE_X2> x2Gm;
    GlobalTensor<DTYPE_Y> yGm;
    LocalTensor<half> zero;//暂时无用
    uint32_t coreDataNum;//核（core）的数据个数
    uint32_t tileNum;//几个tile
    uint32_t tileDataNum;//一个TILE的数据个数
    uint32_t tailDataNum;//尾tile的数据个数
    uint32_t processDataNum;//本个tile的数据个数,属于中间变量，不属于tile结构体
    uint32_t x1Size,x2Size;
};



extern "C" __global__ __aicore__ void pows(GM_ADDR x1, GM_ADDR x2, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    // TODO: user kernel impl  
    if(TILING_KEY_IS(1))  
    {
        KernelPows<DTYPE_X1> op;
        printf("核函数调用一次gmaddr x1：%ld\n",(uint64_t)x1);
        op.Init(x1,x2,y,
            tiling_data.CoreDataNum, tiling_data.finalTileNum, tiling_data.tileDataNum, tiling_data.TailDataNum);
        op.Process();
    }
    else if(TILING_KEY_IS(2))
    {
        KernelPowsBroadcast<DTYPE_X1> op;
        //printf("广播模式核函数调用一次gmaddr x1：%ld\n",(uint64_t)x1);
        op.Init(x1,x2,y,
            tiling_data.CoreDataNum, tiling_data.finalTileNum, tiling_data.tileDataNum, tiling_data.TailDataNum,
            tiling_data.x1Size, tiling_data.x2Size);
        op.Process();
    }

}