#include "kernel_operator.h"


using namespace AscendC;

__aicore__ inline int align_to(int a, int b) {
    return (a + b - 1) / b * b;
}

template<typename T>
class KernelGluJvp {
public:
    __aicore__ inline KernelGluJvp() {}
    
    // __aicore__ inline void Init(GM_ADDR glu_out, GM_ADDR input, GM_ADDR v, GM_ADDR jvp_out, bool use_glu_out)
    __aicore__ inline void Init(GM_ADDR input, GM_ADDR v, GM_ADDR jvp_out)
    {
        // gluOutGm.SetGlobalBuffer((__gm__ T *)glu_out);
        inputGm.SetGlobalBuffer((__gm__ T *)input);
        vGm.SetGlobalBuffer((__gm__ T *)v);
        jvpOutGm.SetGlobalBuffer((__gm__ T *)jvp_out);
        
        // 合并后的缓冲区初始化 max 4915 for float 3780 for half
        pipe.InitBuffer(inQueue, BUFFER_NUM, 4 * chunksize * sizeof(T)); // input, v, glu_out
        pipe.InitBuffer(outQueue, BUFFER_NUM, chunksize * sizeof(T)); // jvp_out
        if(sizeof(T) == 2)
            pipe.InitBuffer(workQueue, BUFFER_NUM, 4 * chunksize * sizeof(float)); // temp1, temp2, temp3
    }
    __aicore__ inline void Process(int input_offset1, int input_offset2, int jvp_out_offset, int size)
    {
        LocalTensor<T> combinedLocal = inQueue.AllocTensor<T>();
        DataCopy(combinedLocal, inputGm[input_offset1], 2 * size);
        DataCopy(combinedLocal[2*chunksize], vGm[input_offset1], 2 * size);
        inQueue.EnQue(combinedLocal);
        inQueue.DeQue<T>();
        
        LocalTensor<T> jvpOutLocal = outQueue.AllocTensor<T>();
        
        // 使用offset访问不同部分
        LocalTensor<T> x1 = combinedLocal;
        LocalTensor<T> x2 = combinedLocal[size];
        LocalTensor<T> v1 = combinedLocal[2*chunksize];
        LocalTensor<T> v2 = combinedLocal[2*chunksize+size];
        
        if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {
            LocalTensor<float> workLocal = workQueue.AllocTensor<float>();
            LocalTensor<float> x1_f = workLocal;                       
            LocalTensor<float> x2_f = workLocal[size];             
            LocalTensor<float> v1_f = workLocal[2*chunksize];              
            LocalTensor<float> v2_f = workLocal[2*chunksize+size];     
            
            // 一次性转换input和v (1次cast)
            Cast(workLocal, combinedLocal, RoundMode::CAST_NONE, 2*size);        
            Cast(workLocal[2*chunksize], combinedLocal[2*chunksize], RoundMode::CAST_NONE, 2*size);              
            
            Sigmoid(x2_f, x2_f, size); // sigmoid_x2
            // DumpTensor(x2_f, 0, 8);
            Mul(v1_f, x2_f, v1_f, size); // 前半部分: v1 * sigmoid_x2
            // DumpTensor(v1_f, 1, 8);
            Mul(x1_f, x1_f, x2_f, size); // x1 * sigmoid_x2
            // DumpTensor(x1_f, 2, 8);
            Adds(x2_f, x2_f, -1.0f, size); // sigmoid_x2 - 1
            // DumpTensor(x2_f, 3, 8);
            Mul(x2_f, x2_f, v2_f, size); // (sigmoid_x2 - 1) * v2
            // DumpTensor(x1_f, 4, 8);
            Mul(x1_f, x1_f, x2_f, size); // x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2
            // DumpTensor(x1_f, 5, 8);
            Sub(v1_f, v1_f, x1_f, size); // v1 * sigmoid_x2 - x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2
            // DumpTensor(v1_f, 6, 8);
            Cast(jvpOutLocal, v1_f, RoundMode::CAST_RINT, size);
            // DumpTensor(jvpOutLocal, 7, 32);
            workQueue.FreeTensor(workLocal);
        } else {
            Sigmoid(x2, x2, size); // sigmoid_x2
            
            Mul(jvpOutLocal, x2, v1, size); // 前半部分: v1 * sigmoid_x2
            
            Mul(x1, x1, x2, size); // x1 * sigmoid_x2

            Adds(x2, x2, -1.0f, size); // sigmoid_x2 - 1
            
            Mul(x2, x2, v2, size); // (sigmoid_x2 - 1) * v2

            Mul(x1, x1, x2, size); // x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2

            Sub(jvpOutLocal, jvpOutLocal, x1, size); // v1 * sigmoid_x2 - x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2
        }
        
        outQueue.EnQue(jvpOutLocal);
        inQueue.FreeTensor(combinedLocal);
        
        outQueue.DeQue<T>();
        DataCopy(jvpOutGm[jvp_out_offset], jvpOutLocal, size);
        outQueue.FreeTensor(jvpOutLocal);
    }
    __aicore__ inline void ProcessSlice(int input_offset1, int input_offset2, int jvp_out_offset, int size)
    {
        int loop = (size + chunksize - 1) / chunksize;
        int tile = size % chunksize;
        tile = tile == 0 ? chunksize : tile;

        this->input_offset1 = input_offset1;
        this->input_offset2 = input_offset2;
        // this->glu_out_offset = glu_out_offset;
        this->jvp_out_offset = jvp_out_offset;
        
        for(int i = 0; i != loop - 1; i++) {
            CopyIn(i * chunksize, chunksize);
            ComputeWithoutGluOut(chunksize);
            CopyOut(i * chunksize, chunksize);
        }
        
        // 处理最后一块
        int last_size = chunksize;
        CopyIn((loop - 1) * chunksize, align_to(tile, block_len));
        ComputeWithoutGluOut(align_to(tile, block_len));
        if(tile % block_len) {
            CopyOutPad((loop - 1) * chunksize, tile);
        } else {
            CopyOut((loop - 1) * chunksize, tile);
        }
    }

private:
    __aicore__ inline void CopyIn(int offset, int len)
    {
        LocalTensor<T> combinedLocal = inQueue.AllocTensor<T>();
        // DataCopyParams copyParams;
        // copyParams.blockCount = 2;
        // copyParams.blockLen = len / block_len;
        // copyParams.srcStride = (input_offset2 - input_offset1 - len) / block_len;
        // copyParams.dstStride = (chunksize - len) / block_len;
        
        DataCopy(combinedLocal, inputGm[input_offset1 + offset], len);
        DataCopy(combinedLocal[chunksize], inputGm[input_offset2 + offset], len);
        DataCopy(combinedLocal[2*chunksize], vGm[input_offset1 + offset], len);
        DataCopy(combinedLocal[3*chunksize], vGm[input_offset2 + offset], len);
        // if (use_glu_out) {
        //     DataCopy(combinedLocal[4*chunksize], gluOutGm[glu_out_offset+offset], chunksize);
        // }
        
        inQueue.EnQue(combinedLocal);
    }
    
//     __aicore__ inline void ComputeWithGluOut()
//     {
//         LocalTensor<T> combinedLocal = inQueue.DeQue<T>();
//         LocalTensor<T> jvpOutLocal = outQueue.AllocTensor<T>();
//         LocalTensor<float> workLocal = workQueue.AllocTensor<float>();
        
//         // 使用offset访问不同部分
//         LocalTensor<T> x1 = combinedLocal;
//         // LocalTensor<T> x2 = combinedLocal[chunksize];
//         LocalTensor<T> v1 = combinedLocal[2*chunksize];
//         LocalTensor<T> v2 = combinedLocal[3*chunksize];
//         LocalTensor<T> glu_out = combinedLocal[4*chunksize];
        
//         if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {

//             LocalTensor<float> x1_f = workLocal;                       
//             // LocalTensor<float> x2_f = workLocal[chunksize];             
//             LocalTensor<float> v1_f = workLocal[2*chunksize];              
//             LocalTensor<float> v2_f = workLocal[3*chunksize];     
//             LocalTensor<float> glu_out_f = workLocal[4*chunksize];     
            
//             // 一次性转换input和v (1次cast)
//             Cast(workLocal, combinedLocal, RoundMode::CAST_NONE, 5*chunksize);        
            
//             Div(x1_f, glu_out_f, x1_f, chunksize); // sigmoid_x2
            
//             Mul(v1_f, x1_f, v1_f, chunksize); // 前半部分: v1 * sigmoid_x2

//             Adds(x1_f, x1_f, -1.0f, chunksize); // sigmoid_x2 - 1
            
//             Mul(x1_f, x1_f, v2_f, chunksize); // (sigmoid_x2 - 1) * v2

//             Mul(x1_f, x1_f, glu_out_f, chunksize); // x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2

//             Sub(v1_f, v1_f, x1_f, chunksize); // v1 * sigmoid_x2 - x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2

//             Cast(jvpOutLocal, v1_f, RoundMode::CAST_RINT, chunksize);
//         } else {
//             Div(x1, glu_out, x1, chunksize); // sigmoid_x2
            
//             Mul(jvpOutLocal, x1, v1, chunksize); // 前半部分: v1 * sigmoid_x2

//             Adds(x1, x1, -1.0f, chunksize); // sigmoid_x2 - 1
            
//             Mul(x1, x1, v2, chunksize); // (sigmoid_x2 - 1) * v2

//             Mul(x1, x1, glu_out, chunksize); // x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2

//             Sub(jvpOutLocal, jvpOutLocal, x1, chunksize); // v1 * sigmoid_x2 - x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2
//         }
        
//         outQueue.EnQue(jvpOutLocal);
//         workQueue.FreeTensor(workLocal);
//         inQueue.FreeTensor(combinedLocal);
//     }

    __aicore__ inline void ComputeWithoutGluOut(int len)
    {
        LocalTensor<T> combinedLocal = inQueue.DeQue<T>();
        LocalTensor<T> jvpOutLocal = outQueue.AllocTensor<T>();
        
        // 使用offset访问不同部分
        LocalTensor<T> x1 = combinedLocal;
        LocalTensor<T> x2 = combinedLocal[chunksize];
        LocalTensor<T> v1 = combinedLocal[2*chunksize];
        LocalTensor<T> v2 = combinedLocal[3*chunksize];
        
        if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {
            LocalTensor<float> workLocal = workQueue.AllocTensor<float>();
            LocalTensor<float> x1_f = workLocal;                       
            LocalTensor<float> x2_f = workLocal[chunksize];             
            LocalTensor<float> v1_f = workLocal[2*chunksize];              
            LocalTensor<float> v2_f = workLocal[3*chunksize];     
            
            // 一次性转换input和v (1次cast)
            Cast(workLocal, combinedLocal, RoundMode::CAST_NONE, 4*chunksize);        
            
            Sigmoid(x2_f, x2_f, len); // sigmoid_x2
            // DumpTensor(x2_f, 0, 8);
            Mul(v1_f, x2_f, v1_f, len); // 前半部分: v1 * sigmoid_x2
            // DumpTensor(v1_f, 1, 8);
            Mul(x1_f, x1_f, x2_f, len); // x1 * sigmoid_x2
            // DumpTensor(x1_f, 2, 8);
            Adds(x2_f, x2_f, -1.0f, len); // sigmoid_x2 - 1
            // DumpTensor(x2_f, 3, 8);
            Mul(x2_f, x2_f, v2_f, len); // (sigmoid_x2 - 1) * v2
            // DumpTensor(x1_f, 4, 8);
            Mul(x1_f, x1_f, x2_f, len); // x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2
            // DumpTensor(x1_f, 5, 8);
            Sub(v1_f, v1_f, x1_f, len); // v1 * sigmoid_x2 - x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2
            // DumpTensor(v1_f, 6, 8);
            Cast(jvpOutLocal, v1_f, RoundMode::CAST_RINT, len);
            // DumpTensor(jvpOutLocal, 7, 32);
            workQueue.FreeTensor(workLocal);
        } else {
            Sigmoid(x2, x2, len); // sigmoid_x2
            
            Mul(jvpOutLocal, x2, v1, len); // 前半部分: v1 * sigmoid_x2
            
            Mul(x1, x1, x2, len); // x1 * sigmoid_x2

            Adds(x2, x2, -1.0f, len); // sigmoid_x2 - 1
            
            Mul(x2, x2, v2, len); // (sigmoid_x2 - 1) * v2

            Mul(x1, x1, x2, len); // x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2

            Sub(jvpOutLocal, jvpOutLocal, x1, len); // v1 * sigmoid_x2 - x1 * sigmoid_x2 * (sigmoid_x2 - 1) * v2
        }
        
        outQueue.EnQue(jvpOutLocal);
        inQueue.FreeTensor(combinedLocal);
    }
    
    __aicore__ inline void CopyOut(int offset, int len)
    {
        LocalTensor<T> jvpOutLocal = outQueue.DeQue<T>();
        DataCopy(jvpOutGm[offset + jvp_out_offset], jvpOutLocal, len);
        outQueue.FreeTensor(jvpOutLocal);
    }
    
    __aicore__ inline void CopyOutPad(int offset, int len)
    {
        DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        LocalTensor<T> jvpOutLocal = outQueue.DeQue<T>();
        DataCopyPad(jvpOutGm[offset + jvp_out_offset], jvpOutLocal, copyParams);
        outQueue.FreeTensor(jvpOutLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, 1> inQueue;    // 合并的输入队列
    TQue<QuePosition::VECOUT, 1> outQueue; // 输出队列
    TQue<QuePosition::VECIN, 1> workQueue; // 合并的工作队列
    
    // GlobalTensor<T> gluOutGm;
    GlobalTensor<T> inputGm;
    GlobalTensor<T> vGm;
    GlobalTensor<T> jvpOutGm;
    
    // bool use_glu_out;
    // max 4915 for float 3780 for half
    int chunksize = sizeof(T) == 2 ? 3072 : 4608;
    int BUFFER_NUM = 2;
    int input_offset1, input_offset2, jvp_out_offset;
    int block_len = 32 / sizeof(T);
};

extern "C" __global__ __aicore__ void glu_jvp(GM_ADDR glu_out, GM_ADDR input, GM_ADDR v, 
                                               GM_ADDR jvp_out, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    const uint32_t* input_shape = tiling_data.input_shape;
    const uint32_t data_type = tiling_data.data_type;
    const uint32_t dim = tiling_data.dim;
    
    // 1. 添加if_use_glu_out参数
    // bool if_use_glu_out = false; // 可以修改这里来选择使用哪种方式
    int chunksize = data_type == 2 ? 4608 : 3072;
    int threshold = data_type == 2 ? 204800 : 409600;
    int blockIdx = GetBlockIdx();
    int blockDim = GetBlockNum();
    uint32_t total_dims = input_shape[0];
    uint32_t dim_size = input_shape[dim + 1];
    
    // 2. 修改为固定长度数组
    uint32_t strides[8];
    strides[total_dims - 1] = 1;
    for (int i = total_dims - 2; i >= 0; i--) {
        strides[i] = strides[i + 1] * input_shape[i + 2];
    }
    
    // 计算总元素数量
    uint32_t total_elements = 1;
    for (int i = 1; i <= total_dims; i++) {
        total_elements *= input_shape[i];
    }
    
    if (dim == 0) {
        // dim=0：逻辑统一，只是cacheline大小不同
        int cacheline;
        if (data_type == 2) { // float
            cacheline = 64;
        } else { // half 或 bfloat16
            cacheline = 128;
        }

        uint32_t half_elements = total_elements / 2;
        int chunks = (half_elements + cacheline - 1) / cacheline;
        int base_chunks = chunks / blockDim;
        int tile_chunks = chunks % blockDim;
        int start = (base_chunks * blockIdx + min(blockIdx, tile_chunks)) * cacheline;
        int len = min(int(half_elements) - start, (base_chunks + (blockIdx < tile_chunks)) * cacheline);

        if(len <= 0) return;

        uint32_t input_offset1 = start;
        uint32_t input_offset2 = start + half_elements;
        // uint32_t glu_out_offset = start;
        uint32_t jvp_out_offset = start;
        // if(len % chunksize < 1024) return;
        // 根据数据类型选择对应的kernel
        if (data_type == 2) { // float
            KernelGluJvp<float> op;
            op.Init(input, v, jvp_out);
            GlobalTensor<int32_t> workGm;
            workGm.SetGlobalBuffer((__gm__ int32_t *)workspace);
            // PRINTF("%d %d %d %d %d %d \n", total_elements, input_offset1, input_offset2, glu_out_offset, jvp_out_offset, len);
            if(workGm(0)%2 && len > threshold) {
                int loop = len / threshold;
                while(loop) {
                    op.ProcessSlice(input_offset1+len-loop*threshold, input_offset2+len-loop*threshold, jvp_out_offset+len-loop*threshold, threshold);
                    loop--;
                }
                if(len % threshold)
                    op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len%threshold);
            } else {
                op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len);
            }
            if(blockIdx == 0) workGm(0) += 1;
            // op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len);
        } else if (data_type == 1) { // half
            KernelGluJvp<half> op;
            op.Init(input, v, jvp_out);
            // PRINTF("%d %d %d %d %d %d \n", total_elements, input_offset1, input_offset2, glu_out_offset, jvp_out_offset, len);
            if(GetSystemCycle()%2 && len > threshold) {
                int loop = len / threshold;
                while(loop) {
                    op.ProcessSlice(input_offset1+len-loop*threshold, input_offset2+len-loop*threshold, jvp_out_offset+len-loop*threshold, threshold);
                    loop--;
                }
                if(len % threshold)
                    op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len%threshold);
            } else {
                op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len);
            }
            // op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len);
        } else { // bfloat16
            KernelGluJvp<bfloat16_t> op;
            op.Init(input, v, jvp_out);
            // PRINTF("%d %d %d %d %d %d \n", total_elements, input_offset1, input_offset2, glu_out_offset, jvp_out_offset, len);
            if(GetSystemCycle()%2 && len > threshold) {
                int loop = len / threshold;
                while(loop) {
                    op.ProcessSlice(input_offset1+len-loop*threshold, input_offset2+len-loop*threshold, jvp_out_offset+len-loop*threshold, threshold);
                    loop--;
                }
                if(len % threshold)
                    op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len%threshold);
            } else {
                op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len);
            }
            // op.ProcessSlice(input_offset1, input_offset2, jvp_out_offset, len);
        }
    } else {
        // dim!=0：需要分别处理每种数据类型
        uint32_t split_size = dim_size / 2;
        uint32_t elements_per_split = strides[dim];
        uint32_t total_splits = total_elements / (dim_size * elements_per_split);
        
        uint32_t splits_per_core = total_splits / blockDim;
        uint32_t remaining_splits = total_splits % blockDim;
        
        uint32_t start_split, end_split;
        if (blockIdx < remaining_splits) {
            start_split = blockIdx * (splits_per_core + 1);
            end_split = start_split + splits_per_core + 1;
        } else {
            start_split = remaining_splits * (splits_per_core + 1) + (blockIdx - remaining_splits) * splits_per_core;
            end_split = start_split + splits_per_core;
        }

        uint32_t num_splits_for_core = (end_split > start_split) ? (end_split - start_split) : 0;
        if (num_splits_for_core == 0) {
            return;
        }
        uint32_t split_elements = split_size * elements_per_split;
        uint32_t core_total_elements = num_splits_for_core * split_elements;

        bool process_in_reverse = (GetSystemCycle() % 2) && (core_total_elements > threshold);

        if (data_type == 2) { // float
            KernelGluJvp<float> op;
            op.Init(input, v, jvp_out);
            GlobalTensor<int32_t> workGm;
            workGm.SetGlobalBuffer((__gm__ int32_t *)workspace);
            process_in_reverse = (workGm(0)%2) && (core_total_elements > threshold);
            // --- 修改/恢复的代码块 开始 ---
            if (process_in_reverse) {
                // 反向处理
                for (uint32_t i = 0; i < num_splits_for_core; ++i) {
                    uint32_t split = end_split - 1 - i; // 从后往前获取 split 索引
                    uint32_t base_offset = split * dim_size * elements_per_split;
                    uint32_t input_offset2 = base_offset + split_elements;
                    uint32_t jvp_out_offset = split * split_elements;
                    if(split_elements % 8 == 0 && split_elements <= chunksize) {
                        op.Process(base_offset, input_offset2, jvp_out_offset, split_elements);
                    } else {
                        op.ProcessSlice(base_offset, input_offset2, jvp_out_offset, split_elements);
                    }
                }
            } else {
                // 正向处理
                for (uint32_t split = start_split; split < end_split; split++) {
                    uint32_t base_offset = split * dim_size * elements_per_split;
                    uint32_t input_offset2 = base_offset + split_elements;
                    uint32_t jvp_out_offset = split * split_elements;
                    if(split_elements % 8 == 0 && split_elements <= chunksize) {
                        op.Process(base_offset, input_offset2, jvp_out_offset, split_elements);
                    } else {
                        op.ProcessSlice(base_offset, input_offset2, jvp_out_offset, split_elements);
                    }
                }
            }
            if(blockIdx == 0) workGm(0) += 1;
            // --- 修改/恢复的代码块 结束 ---
            
        } else if (data_type == 1) { // half
            KernelGluJvp<half> op;
            op.Init(input, v, jvp_out);
            
            // --- 修改/恢复的代码块 开始 ---
            if (process_in_reverse) {
                // 反向处理
                for (uint32_t i = 0; i < num_splits_for_core; ++i) {
                    uint32_t split = end_split - 1 - i;
                    uint32_t base_offset = split * dim_size * elements_per_split;
                    uint32_t input_offset2 = base_offset + split_elements;
                    uint32_t jvp_out_offset = split * split_elements;
                    if(split_elements % 16 == 0 && split_elements <= chunksize) {
                        op.Process(base_offset, input_offset2, jvp_out_offset, split_elements);
                    } else {
                        op.ProcessSlice(base_offset, input_offset2, jvp_out_offset, split_elements);
                    }
                }
            } else {
                // 正向处理
                for (uint32_t split = start_split; split < end_split; split++) {
                    uint32_t base_offset = split * dim_size * elements_per_split;
                    uint32_t input_offset2 = base_offset + split_elements;
                    uint32_t jvp_out_offset = split * split_elements;
                    if(split_elements % 16 == 0 && split_elements <= chunksize) {
                        op.Process(base_offset, input_offset2, jvp_out_offset, split_elements);
                    } else {
                        op.ProcessSlice(base_offset, input_offset2, jvp_out_offset, split_elements);
                    }
                }
            }
            // --- 修改/恢复的代码块 结束 ---
            
        } else { // bfloat16
            KernelGluJvp<bfloat16_t> op;
            op.Init(input, v, jvp_out);

            // --- 修改/恢复的代码块 开始 ---
            if (process_in_reverse) {
                // 反向处理
                for (uint32_t i = 0; i < num_splits_for_core; ++i) {
                    uint32_t split = end_split - 1 - i;
                    uint32_t base_offset = split * dim_size * elements_per_split;
                    uint32_t input_offset2 = base_offset + split_elements;
                    uint32_t jvp_out_offset = split * split_elements;
                    if(split_elements % 8 == 0 && split_elements <= chunksize) {
                        op.Process(base_offset, input_offset2, jvp_out_offset, split_elements);
                    } else {
                        op.ProcessSlice(base_offset, input_offset2, jvp_out_offset, split_elements);
                    }
                }
            } else {
                // 正向处理
                for (uint32_t split = start_split; split < end_split; split++) {
                    uint32_t base_offset = split * dim_size * elements_per_split;
                    uint32_t input_offset2 = base_offset + split_elements;
                    uint32_t jvp_out_offset = split * split_elements;
                    if(split_elements % 8 == 0 && split_elements <= chunksize) {
                        op.Process(base_offset, input_offset2, jvp_out_offset, split_elements);
                    } else {
                        op.ProcessSlice(base_offset, input_offset2, jvp_out_offset, split_elements);
                    }
                }
            }
        }
    }
}

