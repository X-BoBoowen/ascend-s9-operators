#include "kernel_operator.h"

using namespace AscendC;

__aicore__ inline int align_to(int a, int b) {
    return (a + b - 1) / b * b;
}

constexpr int32_t threshold = 204800;

template<typename T>
class KernelBitwiseLeftShift {
public:
    __aicore__ inline KernelBitwiseLeftShift() {}
    
    __aicore__ inline void Init(GM_ADDR input, GM_ADDR shift_amount, GM_ADDR output, int mode)
    {
        inputGm.SetGlobalBuffer((__gm__ T *)input);
        shiftGm.SetGlobalBuffer((__gm__ T *)shift_amount);
        outputGm.SetGlobalBuffer((__gm__ T *)output);
        this->mode = mode;
        
        if constexpr (std::is_same_v<T, int8_t> || std::is_same_v<T, int64_t>) {
            pipe.InitBuffer(inQueueA, BUFFER_NUM, chunksize * sizeT);
            pipe.InitBuffer(inQueueB, BUFFER_NUM, chunksize * sizeT);
            pipe.InitBuffer(outQueueC, BUFFER_NUM, chunksize * sizeT);
            pipe.InitBuffer(workQueue1, BUFFER_NUM, 2 * chunksize * sizeT);
            pipe.InitBuffer(workQueue2, BUFFER_NUM, chunksize * sizeT);
            pipe.InitBuffer(maskQueue, BUFFER_NUM, 1024 * sizeof(uint8_t));
        } else if constexpr (std::is_same_v<T, int32_t>) {
            pipe.InitBuffer(inQueueA, BUFFER_NUM, chunksize * sizeT);
            pipe.InitBuffer(inQueueB, BUFFER_NUM, chunksize * sizeT);
            pipe.InitBuffer(outQueueC, BUFFER_NUM, chunksize * sizeT);
            pipe.InitBuffer(workQueue1, BUFFER_NUM, 2 * chunksize * sizeT);
        }
    }
    
    __aicore__ inline void Process(int offsetA, int offsetB, int offsetC, int size)
    {
        int loop = (size + chunksize - 1) / chunksize;
        int tile = size % chunksize;
        tile = tile == 0 ? chunksize : tile;
//         if(mode == 0) {
//             // mode=0: 向量与标量
//             T scalar_shift = shiftGm(offsetB);  // 读取标量移位值
            
//             for(int i = 0; i != loop - 1; i++) {
//                 CopyInMode0(offsetA + i * chunksize, chunksize);
//                 ComputeMode0(chunksize, scalar_shift);
//                 CopyOut(offsetC + i * chunksize, chunksize);
//             }
            
//             CopyInMode0(offsetA + (loop - 1) * chunksize, align_to(tile, 32));
//             ComputeMode0(align_to(tile, 32), scalar_shift);
            
//             if(tile % 32) {
//                 CopyOutPad(offsetC + (loop - 1) * chunksize, tile);
//             } else {
//                 CopyOut(offsetC + (loop - 1) * chunksize, tile);
//             }
//         } else {
            // mode=1: 两个向量
            for(int i = 0; i != loop - 1; i++) {
                CopyInMode1(offsetA + i * chunksize, offsetB + i * chunksize, chunksize);
                ComputeMode1(chunksize);
                CopyOut(offsetC + i * chunksize, chunksize);
            }
            
            CopyInMode1(offsetA + (loop - 1) * chunksize, offsetB + (loop - 1) * chunksize, align_to(tile, 32));
            ComputeMode1(align_to(tile, 32));
            if(tile % 32) {
                CopyOutPad(offsetC + (loop - 1) * chunksize, tile);
            } else {
                CopyOut(offsetC + (loop - 1) * chunksize, tile);
            }
        // }
    }

private:
    // __aicore__ inline void CopyInMode0(int offsetA, int len)
    // {
    //     LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
    //     DataCopy(aLocal, inputGm[offsetA], len);
    //     inQueueA.EnQue(aLocal);
    // }
    
    __aicore__ inline void CopyInMode1(int offsetA, int offsetB, int len)
    {
        LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
        LocalTensor<T> bLocal = inQueueB.AllocTensor<T>();
        DataCopy(aLocal, inputGm[offsetA], len);
        DataCopy(bLocal, shiftGm[offsetB], len);
        inQueueA.EnQue(aLocal);
        inQueueB.EnQue(bLocal);
    }
    
//     __aicore__ inline void ComputeMode0(int len, T scalar_shift)
//     {
//         LocalTensor<T> dataLocal = inQueueA.DeQue<T>();
//         LocalTensor<T> resultLocal = outQueueC.AllocTensor<T>();
        
//         if constexpr (sizeof(T) == 8 || sizeof(T) == 1) {
//             // int64/uint64 使用scalar处理
//             ComputeScalarMode0(resultLocal, dataLocal, scalar_shift, len);
//             inQueueA.FreeTensor(dataLocal);
//             outQueueC.EnQue(resultLocal);
//         } else {
//             // int16/32 使用向量处理
//             ComputeVectorMode0(resultLocal, dataLocal, scalar_shift, len);
//         }
//     }
    
    __aicore__ inline void ComputeMode1(int len)
    {
        LocalTensor<T> dataLocal = inQueueA.DeQue<T>();
        LocalTensor<T> shiftLocal = inQueueB.DeQue<T>();
        LocalTensor<T> resultLocal = outQueueC.AllocTensor<T>();
        
        if constexpr (sizeof(T) == 8) {
            // int64/uint64 使用scalar处理
            ComputeScalarMode1(resultLocal, dataLocal, shiftLocal, len);
            inQueueA.FreeTensor(dataLocal);
            inQueueB.FreeTensor(shiftLocal);
            outQueueC.EnQue(resultLocal);
        } else if constexpr (sizeof(T) == 1) {
            // int8/uint8 转换为half处理
            ComputeInt8Mode1(resultLocal, dataLocal, shiftLocal, len);
        } else if constexpr (std::is_same_v<T, int32_t>) {
            // int16/32 使用向量处理
            ComputeVectorMode1_mul(resultLocal, dataLocal, shiftLocal, len);
        }
    }
    
    __aicore__ inline void ComputeInt8Mode1(LocalTensor<T>& result,
                                           LocalTensor<T>& data,
                                           LocalTensor<T>& shifts,
                                           int len)
    {
        LocalTensor<half> workLocal1 = workQueue1.AllocTensor<half>();
        LocalTensor<half> workLocal2 = workQueue2.AllocTensor<half>();
        LocalTensor<uint8_t> maskLocal = maskQueue.AllocTensor<uint8_t>();
        
        // 转换为half - 原地操作
        Cast(workLocal1, data, RoundMode::CAST_NONE, len); // workLocal1现在是half类型的data
        Cast(workLocal1[chunksize], shifts, RoundMode::CAST_NONE, len);
        Duplicate(workLocal2, static_cast<half>(0), len); // result初始化为0的half版本
        
        for(int shift_val = 0; shift_val < MAX_SHIFT; shift_val++) {

            CompareScalar(maskLocal, workLocal1[chunksize], static_cast<half>(shift_val), CMPMODE::EQ, static_cast<uint32_t>(align_to(len, 256/sizeof(T))));
            if(shift_val == 0) {
                // 移位0位，直接使用原数据
                Select(workLocal2, maskLocal, workLocal1, workLocal2, SELMODE::VSEL_TENSOR_TENSOR_MODE, static_cast<uint32_t>(len));
            } else {
                // 计算2^shift_val并执行乘法
                half multiplier = static_cast<half>(1 << shift_val);
                Muls(workLocal2[chunksize], workLocal1, multiplier, len);
                Select(workLocal2, maskLocal, workLocal2[chunksize], workLocal2, SELMODE::VSEL_TENSOR_TENSOR_MODE, static_cast<uint32_t>(len));
            }
        }
        
        // 转换回int8 - 原地操作
        Cast(result, workLocal2, RoundMode::CAST_TRUNC, len);
        workQueue1.FreeTensor(workLocal1);
        workQueue2.FreeTensor(workLocal2);
        maskQueue.FreeTensor(maskLocal);

        outQueueC.EnQue(result);
        inQueueA.FreeTensor(data);
        inQueueB.FreeTensor(shifts);
    }
    
//     __aicore__ inline void ComputeVectorMode0(LocalTensor<T>& result, 
//                                              LocalTensor<T>& data, 
//                                              T scalar_shift,
//                                              int len)
//     {
//         constexpr int MAX_SHIFT = sizeof(T) * 8;
        
//         if(scalar_shift < 0 || scalar_shift >= MAX_SHIFT) {
//             // 超出范围，结果为0
//             Duplicate(result, static_cast<T>(0), len);
//         // } else if(scalar_shift == 0) {
//         //     Muls(result, data, static_cast<T>(1),len);
//         } else {
//             // 执行左移操作
//             ShiftLeft(result, data, static_cast<T>(scalar_shift), len);
//         }
//         outQueueC.EnQue(result);
//         inQueueA.FreeTensor(data);
//     }
    
    __aicore__ inline void ComputeVectorMode1_mul(LocalTensor<T>& result, 
                                             LocalTensor<T>& data, 
                                             LocalTensor<T>& shifts, 
                                             int len)
    {
        LocalTensor<float> workLocal1 = workQueue1.AllocTensor<float>();
        
        // 初始化结果为0
        Cast(workLocal1, shifts, RoundMode::CAST_NONE, len);
        Muls(workLocal1, workLocal1, 0.69314718f, len);
        Exp(workLocal1[chunksize], workLocal1, len);
        Cast(result, workLocal1[chunksize], RoundMode::CAST_TRUNC, len);
        Mul(result, data, result, len);

        workQueue1.FreeTensor(workLocal1);

        outQueueC.EnQue(result);
        inQueueA.FreeTensor(data);
        inQueueB.FreeTensor(shifts);
    }

//     __aicore__ inline void ComputeScalarMode0(LocalTensor<T>& result,
//                                              LocalTensor<T>& data,
//                                              T scalar_shift,
//                                              int len)
//     {
//         constexpr int MAX_SHIFT = sizeof(T) * 8;
        
//         for(int i = 0; i < len; i++) {
//             T data_val = data.GetValue(i);
//             T result_val;
            
//             if(scalar_shift < 0 || scalar_shift >= MAX_SHIFT) {
//                 result_val = 0;
//             } else {
//                 result_val = data_val << scalar_shift;
//             }
            
//             result.SetValue(i, result_val);
//         }
//     }
    
    __aicore__ inline void ComputeScalarMode1(LocalTensor<T>& result,
                                             LocalTensor<T>& data,
                                             LocalTensor<T>& shifts,
                                             int len)
    {
        for(int i = 0; i < len; i++) {
            T data_val = data.GetValue(i);
            T shift_val = shifts.GetValue(i);
            
            T result_val;
            if(shift_val < 0 || shift_val >= MAX_SHIFT) {
                result_val = 0;
            } else {
                result_val = data_val << shift_val;
            }
            
            result.SetValue(i, result_val);
        }
    }
    
    __aicore__ inline void CopyOut(int offsetC, int len)
    {
        LocalTensor<T> cLocal = outQueueC.DeQue<T>();
        DataCopy(outputGm[offsetC], cLocal, len);
        outQueueC.FreeTensor(cLocal);
    }
    
    __aicore__ inline void CopyOutPad(int offsetC, int len)
    {
        DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        LocalTensor<T> cLocal = outQueueC.DeQue<T>();
        DataCopyPad(outputGm[offsetC], cLocal, copyParams);
        outQueueC.FreeTensor(cLocal);
    }

private:
    static constexpr int BUFFER_NUM = 2;
    static constexpr int chunksize = sizeof(T) == 4 ? 3072 : 1280;
    static constexpr int sizeT = sizeof(T) == 8 ? 8 : 4;
    static constexpr int MAX_SHIFT = sizeof(T) * 8;
    
    TPipe pipe;
    TQue<QuePosition::VECIN, 1> inQueueA;
    TQue<QuePosition::VECIN, 1> inQueueB;
    TQue<QuePosition::VECOUT, 1> outQueueC;
    TQue<QuePosition::VECIN, 1> workQueue1;
    TQue<QuePosition::VECIN, 1> workQueue2;
    TQue<QuePosition::VECIN, 1> maskQueue;
    
    GlobalTensor<T> inputGm;
    GlobalTensor<T> shiftGm;
    GlobalTensor<T> outputGm;
    int mode;
};

class KernelBitwiseLeftShift32 {
public:
    __aicore__ inline KernelBitwiseLeftShift32() {}
    
    __aicore__ inline void Init(GM_ADDR input, GM_ADDR shift_amount, GM_ADDR output)
    {
        inputGm.SetGlobalBuffer((__gm__ int32_t *)input);
        shiftGm.SetGlobalBuffer((__gm__ int32_t *)shift_amount);
        outputGm.SetGlobalBuffer((__gm__ int32_t *)output);
        
        pipe.InitBuffer(inQueueA, BUFFER_NUM, chunksize * 4);
        pipe.InitBuffer(inQueueB, BUFFER_NUM, chunksize * 4);
        pipe.InitBuffer(outQueueC, BUFFER_NUM, chunksize * 4);
        pipe.InitBuffer(workQueue1, BUFFER_NUM, 2 * chunksize * 4);
    }
    
    __aicore__ inline void Process(int offsetA, int offsetB, int offsetC, int size)
    {
        int loop = (size + chunksize - 1) / chunksize;
        int tile = size % chunksize;
        tile = tile == 0 ? chunksize : tile;
        for(int i = 0; i != loop - 1; i++) {
            CopyInMode1(offsetA + i * chunksize, offsetB + i * chunksize, chunksize);
            ComputeMode1(chunksize);
            CopyOut(offsetC + i * chunksize, chunksize);
        }
        
        CopyInMode1(offsetA + (loop - 1) * chunksize, offsetB + (loop - 1) * chunksize, align_to(tile, 32));
        ComputeMode1(align_to(tile, 32));
        if(tile % 32) {
            CopyOutPad(offsetC + (loop - 1) * chunksize, tile);
        } else {
            CopyOut(offsetC + (loop - 1) * chunksize, tile);
        }
        // }
    }

private:
    __aicore__ inline void CopyInMode1(int offsetA, int offsetB, int len)
    {
        LocalTensor<int32_t> aLocal = inQueueA.AllocTensor<int32_t>();
        LocalTensor<int32_t> bLocal = inQueueB.AllocTensor<int32_t>();
        DataCopy(aLocal, inputGm[offsetA], len);
        DataCopy(bLocal, shiftGm[offsetB], len);
        inQueueA.EnQue(aLocal);
        inQueueB.EnQue(bLocal);
    }
    
    __aicore__ inline void ComputeMode1(int len)
    {
        LocalTensor<int32_t> dataLocal = inQueueA.DeQue<int32_t>();
        LocalTensor<int32_t> shiftLocal = inQueueB.DeQue<int32_t>();
        LocalTensor<int32_t> resultLocal = outQueueC.AllocTensor<int32_t>();

        LocalTensor<float> workLocal1 = workQueue1.AllocTensor<float>();
        
        // 初始化结果为0
        Cast(workLocal1, shiftLocal, RoundMode::CAST_NONE, len);
        Muls(workLocal1, workLocal1, 0.69314718f, len);
        Exp(workLocal1[chunksize], workLocal1, len);
        // Power(workLocal1[chunksize], 2.0f, workLocal1, len);
        Cast(resultLocal, workLocal1[chunksize], RoundMode::CAST_TRUNC, len);
        Mul(resultLocal, dataLocal, resultLocal, len);

        workQueue1.FreeTensor(workLocal1);
        inQueueA.FreeTensor(dataLocal);
        inQueueB.FreeTensor(shiftLocal);
        outQueueC.EnQue(resultLocal);
    }
    
    __aicore__ inline void CopyOut(int offsetC, int len)
    {
        LocalTensor<int32_t> cLocal = outQueueC.DeQue<int32_t>();
        DataCopy(outputGm[offsetC], cLocal, len);
        outQueueC.FreeTensor(cLocal);
    }
    
    __aicore__ inline void CopyOutPad(int offsetC, int len)
    {
        DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(int32_t)), 0, 0, 0};
        LocalTensor<int32_t> cLocal = outQueueC.DeQue<int32_t>();
        DataCopyPad(outputGm[offsetC], cLocal, copyParams);
        outQueueC.FreeTensor(cLocal);
    }

private:
    static constexpr int BUFFER_NUM = 2;
    static constexpr int chunksize = 3072;
    
    TPipe pipe;
    TQue<QuePosition::VECIN, 1> inQueueA;
    TQue<QuePosition::VECIN, 1> inQueueB;
    TQue<QuePosition::VECOUT, 1> outQueueC;
    TQue<QuePosition::VECIN, 1> workQueue1;
    
    GlobalTensor<int32_t> inputGm;
    GlobalTensor<int32_t> shiftGm;
    GlobalTensor<int32_t> outputGm;
};



extern "C" __global__ __aicore__ void bitwise_left_shift(GM_ADDR input, GM_ADDR other, GM_ADDR output, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    const uint32_t* input_shape = tiling_data.input_shape;
    const uint32_t* other_shape = tiling_data.other_shape;
    // const uint32_t* output = tiling_data.output_shape;
    const uint32_t data_type = tiling_data.data_type;
    const uint32_t mode = tiling_data.mode;
    const uint32_t input_size = tiling_data.input_size;
    int blockIdx = GetBlockIdx();
    int blockDim = GetBlockNum();
    int cacheline = 256 / data_type;
    // if(data_type == 1 || data_type == 8) return;
    if(mode == 1 || mode == 0) {
        int chunks = (input_size + cacheline - 1) / cacheline;
        int base_chunks = chunks / blockDim;
        int tile_chunks = chunks % blockDim;
        int start = (base_chunks * blockIdx + min(blockIdx, tile_chunks)) * cacheline;
        int len = min(int(input_size) - start, (base_chunks + (blockIdx < tile_chunks)) * cacheline);
        if(len <= 0) return;
        if(data_type == 1) {
            KernelBitwiseLeftShift<int8_t> op;
            op.Init(input, other, output, mode);
            op.Process(start, start * mode, start, len);
        } else if(data_type == 2) {
            // KernelBitwiseLeftShift<int16_t> op;
            // op.Init(input, other, output, mode);
            // op.Process(start, start * mode, start, len);
        } else if(data_type == 4) {
            KernelBitwiseLeftShift32 op;
            op.Init(input, other, output);
            GlobalTensor<int32_t> workGm;
            workGm.SetGlobalBuffer((__gm__ int32_t *)workspace);
            if(workGm(0)%2 && len > threshold) {
                op.Process(start+len-threshold, start+len-threshold, start+len-threshold, threshold);
                op.Process(start, start, start, len-threshold);
            }else {
                op.Process(start, start, start, len);
            }
            if(blockIdx == 0) workGm(0) += 1;
        } else {
            KernelBitwiseLeftShift<int64_t> op;
            op.Init(input, other, output, mode);
            op.Process(start, start * mode, start, len);
        }
    } else {
        // 处理广播情况
        int input_dims = input_shape[0];
        int other_dims = other_shape[0];

        uint32_t input_total = input_size;

        uint32_t continuous_input_len = 1;
        bool use_scalar_mode = false;

        // 最后一维分析
        uint32_t last_input_dim = input_shape[input_dims];
        uint32_t last_other_dim = (other_dims > 0) ? other_shape[other_dims] : 1;

        if(last_other_dim == 1) {
            // other最后一维是1，标量模式
            use_scalar_mode = true;
            continuous_input_len = last_input_dim;
        } else if(last_other_dim == last_input_dim) {
            // 最后一维匹配，向量模式
            use_scalar_mode = false;
            continuous_input_len = last_input_dim;
            for(int dim = input_dims - 1; dim >= 1; dim--) {
                uint32_t input_dim_size = input_shape[dim];
                int other_dim_idx = dim - (input_dims - other_dims);
                uint32_t other_dim_size = (other_dim_idx >= 1) ? other_shape[other_dim_idx] : 1;

                if(other_dim_size == input_dim_size) {
                    continuous_input_len *= input_dim_size;
                } else {
                    break; // 不匹配就停止
                }
            }
        } else {
            // 不兼容，fallback
            continuous_input_len = 1;
        }

        // 计算需要外层循环处理的段数
        uint32_t outer_segments = input_total / continuous_input_len;

        // 分块处理
        uint32_t segments_per_block = (outer_segments + blockDim - 1) / blockDim;
        uint32_t start_segment = blockIdx * segments_per_block;
        uint32_t end_segment = min(outer_segments, start_segment + segments_per_block);

        if(start_segment >= outer_segments) return;

        int process_mode = use_scalar_mode ? 0 : 1;
        if(data_type == 1) {
            KernelBitwiseLeftShift<int8_t> op;
            op.Init(input, other, output, process_mode);
            for(uint32_t seg = start_segment; seg < end_segment; seg++) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                // 将input的线性位置转换为多维坐标
                uint32_t coords[10]; // 假设最多10维
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                // 根据坐标和广播规则计算other_offset
                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0; // 广播维度，坐标为0
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }

                op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            }
        } else if(data_type == 2) {
            // KernelBitwiseLeftShift<int16_t> op;
            // op.Init(input, other, output, process_mode);
            // for(uint32_t seg = start_segment; seg < end_segment; seg++) {
            //     uint32_t input_offset = seg * continuous_input_len;

            //     // 计算other偏移 - 修复后的逻辑 (同上)
            //     uint32_t other_offset = 0;
            //     uint32_t input_start_pos = seg * continuous_input_len;

            //     uint32_t coords[10];
            //     uint32_t temp_pos = input_start_pos;
            //     for(int dim = input_dims; dim >= 1; dim--) {
            //         coords[dim-1] = temp_pos % input_shape[dim];
            //         temp_pos /= input_shape[dim];
            //     }

            //     uint32_t other_stride = 1;
            //     for(int dim = other_dims; dim >= 1; dim--) {
            //         uint32_t other_dim_size = other_shape[dim];
            //         int input_dim_idx = dim + (input_dims - other_dims);
            //         uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

            //         if(other_dim_size == 1) {
            //             coord = 0;
            //         }

            //         other_offset += coord * other_stride;
            //         other_stride *= other_dim_size;
            //     }

            //     // PRINTF("%d %d %d %d\n",input_offset, other_offset,continuous_input_len, process_mode);
            //     op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            // }
        } else if(data_type == 4) {
            KernelBitwiseLeftShift32 op;
            op.Init(input, other, output);
            for(uint32_t seg = start_segment; seg < end_segment; seg++) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑 (同上)
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                uint32_t coords[10];
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0;
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }

                // PRINTF("%d %d %d %d\n",input_offset, other_offset,continuous_input_len, process_mode);
                op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            }
        } else {
            KernelBitwiseLeftShift<int64_t> op;
            op.Init(input, other, output, process_mode);
            for(uint32_t seg = start_segment; seg < end_segment; seg++) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑 (同上)
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                uint32_t coords[10];
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0;
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }

                // PRINTF("%d %d %d %d\n",input_offset, other_offset,continuous_input_len, process_mode);
                op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            }
        }
    }
}