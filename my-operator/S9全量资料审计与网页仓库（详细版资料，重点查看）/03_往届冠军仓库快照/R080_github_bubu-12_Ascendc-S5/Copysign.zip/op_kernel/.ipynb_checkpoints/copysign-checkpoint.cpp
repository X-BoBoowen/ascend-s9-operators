#include "kernel_operator.h"

#define MSB_MASK_32 (0x80000000)
#define INV_MSB_MASK_16 (0x7FFF)

using namespace AscendC;
constexpr int32_t BUFFER_NUM = 2;
constexpr int32_t threshold = 204800;
// constexpr int32_t chunksize = 4096;

__aicore__ inline int align_to(int a, int b) {
    return (a + b - 1) / b * b;
}
// 另一种方式是位运算
// template<typename T>
// class KernelCopysign {
// public:
//     __aicore__ inline KernelCopysign() {}  
//     __aicore__ inline void Init(GM_ADDR input, GM_ADDR other, GM_ADDR output, int mode)
//     {
//         inputGm.SetGlobalBuffer((__gm__ T *)input);
//         otherGm.SetGlobalBuffer((__gm__ T *)other);
//         outputGm.SetGlobalBuffer((__gm__ T *)output);
//         pipe.InitBuffer(inQueueA, BUFFER_NUM, chunksize * sizeof(T));
//         pipe.InitBuffer(inQueueB, BUFFER_NUM, chunksize * sizeof(T));
//         pipe.InitBuffer(outQueueC, BUFFER_NUM, chunksize * sizeof(T));
//         pipe.InitBuffer(workQueue, chunksize * sizeof(T)); 
//         this->mode = mode;
//     }
//     __aicore__ inline void Process(int offsetA, int offsetB, int offsetC, int size)
//     {
//         int loop = (size + chunksize - 1) / chunksize;
//         int tile = size % chunksize;
//         tile = tile == 0 ? chunksize : tile;
//         if(mode == 1) {
//             for(int i = 0; i != loop - 1; i++) {
//                 CopyInMode1(offsetA + i * chunksize, offsetB + i * chunksize, chunksize);
//                 ComputeMode1(chunksize);
//                 CopyOut(offsetA + i * chunksize, chunksize);
//             }
//             CopyInMode1(offsetA + (loop - 1) * chunksize, offsetB + (loop - 1) * chunksize, align_to(tile, 16));
//             ComputeMode1(align_to(tile, 16));
//             if(tile % 16) {
//                 CopyOutPad(offsetA + (loop - 1) * chunksize, tile);
//             } else {
//                 CopyOut(offsetA + (loop - 1) * chunksize, tile);
//             }
//         } else {
//             T scalar = otherGm(offsetB);
//             T sign = static_cast<float>(scalar) >= static_cast<float>(0.0) ? static_cast<T>(1) : static_cast<T>(-1);
//             for(int i = 0; i != loop - 1; i++) {
//                 CopyInMode2(offsetA + i * chunksize, chunksize);
//                 ComputeMode2(chunksize, sign);
//                 CopyOut(offsetA + i * chunksize, chunksize);
//             }
//             CopyInMode2(offsetA + (loop - 1) * chunksize, align_to(tile, 16));
//             ComputeMode2(align_to(tile, 16), sign);
//             if(tile % 16) {
//                 CopyOutPad(offsetA + (loop - 1) * chunksize, tile);
//             } else {
//                 CopyOut(offsetA + (loop - 1) * chunksize, tile);
//             }
//         }
//     }

// private:
//     __aicore__ inline void CopyInMode1(int offsetA, int offsetB, int len)
//     {
//         LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
//         LocalTensor<T> bLocal = inQueueB.AllocTensor<T>();
//         DataCopy(aLocal, inputGm[offsetA], len);
//         DataCopy(bLocal, otherGm[offsetB], len);
//         inQueueA.EnQue(aLocal);
//         inQueueB.EnQue(bLocal);
//     }
//     __aicore__ inline void CopyInMode2(int offsetA, int len)
//     {
//         LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
//         DataCopy(aLocal, inputGm[offsetA], len);
//         inQueueA.EnQue(aLocal);
//     }
//     __aicore__ inline void ComputeMode1(int len)
//     {
//         LocalTensor<T> aLocal = inQueueA.DeQue<T>();
//         LocalTensor<T> bLocal = inQueueB.DeQue<T>();
//         LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
//         LocalTensor<uint8_t> workLocal = workQueue.Get<uint8_t>();
//         CompareScalar(workLocal, bLocal, static_cast<T>(0), CMPMODE::GE, len);
//         Abs(aLocal, aLocal, len);
//         Muls(cLocal, aLocal, static_cast<T>(-1), len);
//         Select(cLocal, workLocal, bLocal, cLocal, SELMODE::VSEL_TENSOR_TENSOR_MODE, len);
//         outQueueC.EnQue(cLocal);
//         inQueueB.FreeTensor(bLocal);
//         inQueueA.FreeTensor(aLocal);
//     }
//     __aicore__ inline void ComputeMode2(int len, T sign)
//     {
//         LocalTensor<T> aLocal = inQueueA.DeQue<T>();
//         LocalTensor<T> cLocal = outQueueC.AllocTensor<T>();
//         Abs(aLocal, aLocal, len);
//         Muls(cLocal, aLocal, sign, len);
//         outQueueC.EnQue(cLocal);
//         inQueueA.FreeTensor(aLocal);
//     }
//     __aicore__ inline void CopyOut(int offsetC, int len)
//     {
//         LocalTensor<T> cLocal = outQueueC.DeQue<T>();
//         DataCopy(outputGm[offsetC], cLocal, len);
//         outQueueC.FreeTensor(cLocal);
//     }
//     __aicore__ inline void CopyOutPad(int offsetC, int len)
//     {
//         DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
//         LocalTensor<T> cLocal = outQueueC.DeQue<T>();
//         DataCopyPad(outputGm[offsetC], cLocal, copyParams);
//         outQueueC.FreeTensor(cLocal);
//     }

// private:
//     TPipe pipe;
//     TQue<QuePosition::VECIN, 1> inQueueA;
//     TQue<QuePosition::VECIN, 1> inQueueB;
//     TQue<QuePosition::VECOUT, 1> outQueueC;
//     TBuf<QuePosition::VECCALC> workQueue;
//     GlobalTensor<T> inputGm;
//     GlobalTensor<T> otherGm;
//     GlobalTensor<T> outputGm;
//     int mode;
// };

template<typename T>
class KernelCopysign {
public:
    __aicore__ inline KernelCopysign() {}  
    __aicore__ inline void Init(GM_ADDR input, GM_ADDR other, GM_ADDR output, int mode)
    {
        inputGm.SetGlobalBuffer((__gm__ T *)input);
        otherGm.SetGlobalBuffer((__gm__ T *)other);
        outputGm.SetGlobalBuffer((__gm__ T *)output);
        pipe.InitBuffer(inQueueA, BUFFER_NUM, chunksize * sizeof(T));
        pipe.InitBuffer(inQueueB, BUFFER_NUM, chunksize * sizeof(T));
        pipe.InitBuffer(outQueueC, BUFFER_NUM, chunksize * sizeof(T));
        pipe.InitBuffer(workQueue1, BUFFER_NUM, chunksize * sizeof(T)); 
        pipe.InitBuffer(workQueue2, BUFFER_NUM, chunksize * sizeof(T)); 
        this->mode = mode;
        Prepare();
        // DumpTensor(inputGm, 0, 16);
    }
    __aicore__ inline void Process(int offsetA, int offsetB, int offsetC, int size)
    {
        // DumpTensor(inputGm[32], 0, 16);
        // DumpTensor(otherGm[32], 1, 16);
        int loop = (size + chunksize - 1) / chunksize;
        int tile = size % chunksize;
        tile = tile == 0 ? chunksize : tile;
        if(mode == 1) {
            for(int i = 0; i != loop - 1; i++) {
                CopyInMode1(offsetA + i * chunksize, offsetB + i * chunksize, chunksize);
                ComputeMode1(chunksize);
                CopyOut(offsetA + i * chunksize, chunksize);
            }
            CopyInMode1(offsetA + (loop - 1) * chunksize, offsetB + (loop - 1) * chunksize, align_to(tile, 16));
            ComputeMode1(align_to(tile, 16));
            if(tile % 16) {
                CopyOutPad(offsetA + (loop - 1) * chunksize, tile);
            } else {
                CopyOut(offsetA + (loop - 1) * chunksize, tile);
            }
        } else {
            T scalar = otherGm(offsetB);
            for(int i = 0; i != loop - 1; i++) {
                CopyInMode2(offsetA + i * chunksize, chunksize);
                ComputeMode2(chunksize, scalar);
                CopyOut(offsetA + i * chunksize, chunksize);
            }
            CopyInMode2(offsetA + (loop - 1) * chunksize, align_to(tile, 16));
            ComputeMode2(align_to(tile, 16), scalar);
            if(tile % 16) {
                CopyOutPad(offsetA + (loop - 1) * chunksize, tile);
            } else {
                CopyOut(offsetA + (loop - 1) * chunksize, tile);
            }
        }
        // DumpTensor(outputGm[32], 2, 16);
    }
    __aicore__ inline void Release()
    {
        LocalTensor<T> workLocal1 = workQueue1.DeQue<T>();
        LocalTensor<T> workLocal2 = workQueue2.DeQue<T>();
        workQueue1.FreeTensor(workLocal1);
        workQueue2.FreeTensor(workLocal2);
    }

private:
    __aicore__ inline void Prepare()
    {
        if(sizeof(T) == 4) {
            LocalTensor<uint32_t> workLocal1 = workQueue1.AllocTensor<uint32_t>();
            LocalTensor<uint32_t> workLocal2 = workQueue2.AllocTensor<uint32_t>();
            uint32_t a = ~MSB_MASK_32;
            uint32_t b = MSB_MASK_32;
            Duplicate(workLocal1, a, chunksize);
            Duplicate(workLocal2, b, chunksize);
            workQueue1.EnQue(workLocal1);
            workQueue2.EnQue(workLocal2);
        } else {
            LocalTensor<uint16_t> workLocal1 = workQueue1.AllocTensor<uint16_t>();
            LocalTensor<uint16_t> workLocal2 = workQueue2.AllocTensor<uint16_t>();
            uint16_t a = INV_MSB_MASK_16;
            uint16_t b = ~INV_MSB_MASK_16;
            Duplicate(workLocal1, a, chunksize);
            Duplicate(workLocal2, b, chunksize);
            workQueue1.EnQue(workLocal1);
            workQueue2.EnQue(workLocal2);
        }
    }
    __aicore__ inline void CopyInMode1(int offsetA, int offsetB, int len)
    {
        LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
        LocalTensor<T> bLocal = inQueueB.AllocTensor<T>();
        DataCopy(aLocal, inputGm[offsetA], len);
        DataCopy(bLocal, otherGm[offsetB], len);
        inQueueA.EnQue(aLocal);
        inQueueB.EnQue(bLocal);
    }
    __aicore__ inline void CopyInMode2(int offsetA, int len)
    {
        LocalTensor<T> aLocal = inQueueA.AllocTensor<T>();
        DataCopy(aLocal, inputGm[offsetA], len);
        inQueueA.EnQue(aLocal);
    }
    __aicore__ inline void ComputeMode1(int len)
    {
        int type = sizeof(T) / 2;
        LocalTensor<int16_t> aLocal = inQueueA.DeQue<int16_t>();
        LocalTensor<int16_t> bLocal = inQueueB.DeQue<int16_t>();
        LocalTensor<int16_t> cLocal = outQueueC.AllocTensor<int16_t>();
        LocalTensor<int16_t> workLocal1 = workQueue1.DeQue<int16_t>();
        LocalTensor<int16_t> workLocal2 = workQueue2.DeQue<int16_t>();
        // DumpTensor(workLocal1, 3, 8);
        // DumpTensor(workLocal2, 4, 8);
        And(aLocal, aLocal, workLocal1, len * type);
        And(bLocal, bLocal, workLocal2, len * type);
        // DumpTensor(aLocal, 5, 8);
        // DumpTensor(bLocal, 6, 8);
        Or(cLocal, aLocal, bLocal, len * type);
        // DumpTensor(cLocal, 7, 8);
        outQueueC.EnQue(cLocal);
        // PRINTF("%d \n",len);
        
        workQueue1.EnQue(workLocal1);
        workQueue2.EnQue(workLocal2);
        inQueueB.FreeTensor(bLocal);
        inQueueA.FreeTensor(aLocal);
    }
    __aicore__ inline void ComputeMode2(int len, T scalar)
    {
        LocalTensor<int16_t> aLocal = inQueueA.DeQue<int16_t>();
        LocalTensor<int16_t> workLocal1 = workQueue1.DeQue<int16_t>();
        LocalTensor<int16_t> workLocal2 = workQueue2.DeQue<int16_t>();
        LocalTensor<int16_t> cLocal = outQueueC.AllocTensor<int16_t>();
        if(sizeof(T) == 4) {
            if(static_cast<float>(scalar) < 0) {
                Or(cLocal, aLocal, workLocal2, len*2);
            } else {
                And(cLocal, aLocal, workLocal1, len*2);
            }
        } else {
            if(static_cast<float>(scalar) < 0) {
                Or(cLocal, aLocal, workLocal2, len);
            } else {
                And(cLocal, aLocal, workLocal1, len);
            }
        }
        outQueueC.EnQue(cLocal);
        workQueue1.EnQue(workLocal1);
        workQueue2.EnQue(workLocal2);
        inQueueA.FreeTensor(aLocal);
    }
    __aicore__ inline void CopyOut(int offsetC, int len)
    {
        LocalTensor<T> cLocal = outQueueC.DeQue<T>();
        // PRINTF("%d %d\n", offsetC, len);
        // DumpTensor(cLocal[32], 8, 16);
        DataCopy(outputGm[offsetC], cLocal, len);
        outQueueC.FreeTensor(cLocal);
    }
    __aicore__ inline void CopyOutPad(int offsetC, int len)
    {
        DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        LocalTensor<T> cLocal = outQueueC.DeQue<T>();
        DataCopyPad(outputGm[offsetC], cLocal, copyParams);
        outQueueC.FreeTensor(cLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, 1> inQueueA;
    TQue<QuePosition::VECIN, 1> inQueueB;
    TQue<QuePosition::VECIN, 1> workQueue1;
    TQue<QuePosition::VECIN, 1> workQueue2;
    TQue<QuePosition::VECOUT, 1> outQueueC;
    GlobalTensor<T> inputGm;
    GlobalTensor<T> otherGm;
    GlobalTensor<T> outputGm;
    int mode;
    int chunksize = sizeof(T) == 2 ? 9728 : 4864;
};

extern "C" __global__ __aicore__ void copysign(GM_ADDR input, GM_ADDR other, GM_ADDR output, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    const uint32_t* input_shape = tiling_data.input_shape;
    const uint32_t* other_shape = tiling_data.other_shape;
    // const uint32_t* output = tiling_data.output_shape;
    const uint32_t data_type = tiling_data.data_type;
    const uint32_t mode = tiling_data.mode;
    const uint32_t input_size = tiling_data.input_size;
    int blockIdx = GetBlockIdx();
    int blockDim = GetBlockNum();
    int cacheline = data_type == 1 ? 64 : 128;
    if(mode == 1 || mode == 0) {
        int chunks = (input_size + cacheline - 1) / cacheline;
        int base_chunks = chunks / blockDim;
        int tile_chunks = chunks % blockDim;
        int start = (base_chunks * blockIdx + min(blockIdx, tile_chunks)) * cacheline;
        int len = min(int(input_size) - start, (base_chunks + (blockIdx < tile_chunks)) * cacheline);
        if(len <= 0) return;
        if(data_type == 0 || data_type == 2) {
            KernelCopysign<half> op;
            op.Init(input, other, output, mode);
            op.Process(start, start * mode, start, len);
            op.Release();
        } else if(data_type == 1) {
            GlobalTensor<int32_t> workGm;
            workGm.SetGlobalBuffer((__gm__ int32_t *)workspace);
            if(workGm(0)%2 && len > threshold) 
            {
                KernelCopysign<float> op;
                op.Init(input, other, output, mode);
                // int loop = len / threshold;
                // for(int i = loop; i != 0; i--) {
                //     op.Process(start+len-i*threshold, start * mode+len-i*threshold, start+len-i*threshold, threshold);
                // }
                // if(len % threshold)
                //     op.Process(start, start * mode, start, len - loop * threshold);
                op.Process(start+len-threshold, start * mode+len-threshold, start+len-threshold, threshold);
                op.Process(start, start * mode, start, len - threshold);
                op.Release();
            } else
            {
                KernelCopysign<float> op;
                op.Init(input, other, output, mode);
                op.Process(start, start * mode, start, len);
                op.Release();
            }
            if(blockIdx == 0) workGm(0) += 1;
        } else {
            // KernelCopysign<bfloat16_t> op;
            // op.Init(input, other, output, mode);
            // op.Process(start, start * mode, start, len);
        }
    } else {
        // 处理广播情况
        int input_dims = input_shape[0];
        int other_dims = other_shape[0];

        uint32_t input_total = input_size;

        uint32_t continuous_input_len = 1;
        bool use_scalar_mode = false;

        // 最后一维分析
        uint32_t last_input_dim = input_shape[input_dims];
        uint32_t last_other_dim = (other_dims > 0) ? other_shape[other_dims] : 1;

        if(last_other_dim == 1) {
            // other最后一维是1，标量模式
            use_scalar_mode = true;
            continuous_input_len = last_input_dim;
        } else if(last_other_dim == last_input_dim) {
            // 最后一维匹配，向量模式
            use_scalar_mode = false;
            continuous_input_len = last_input_dim;
            for(int dim = input_dims - 1; dim >= 1; dim--) {
                uint32_t input_dim_size = input_shape[dim];
                int other_dim_idx = dim - (input_dims - other_dims);
                uint32_t other_dim_size = (other_dim_idx >= 1) ? other_shape[other_dim_idx] : 1;

                if(other_dim_size == input_dim_size) {
                    continuous_input_len *= input_dim_size;
                } else {
                    break; // 不匹配就停止
                }
            }
        } else {
            // 不兼容，fallback
            continuous_input_len = 1;
        }

        // 计算需要外层循环处理的段数
        uint32_t outer_segments = input_total / continuous_input_len;

        // 分块处理
        uint32_t segments_per_block = (outer_segments + blockDim - 1) / blockDim;
        uint32_t start_segment = blockIdx * segments_per_block;
        uint32_t end_segment = min(outer_segments, start_segment + segments_per_block);

        if(start_segment >= outer_segments) return;

        int process_mode = use_scalar_mode ? 0 : 1;
        if(data_type == 0 || data_type == 2) {
            KernelCopysign<half> op;
            op.Init(input, other, output, process_mode);
            for(uint32_t seg = start_segment; seg < end_segment; seg++) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                // 将input的线性位置转换为多维坐标
                uint32_t coords[10]; // 假设最多10维
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                // 根据坐标和广播规则计算other_offset
                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0; // 广播维度，坐标为0
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }

                op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            }
            op.Release();
        } else if(data_type == 1) {
            KernelCopysign<float> op;
            op.Init(input, other, output, process_mode);
            for(uint32_t seg = start_segment; seg < end_segment; seg++) {
                uint32_t input_offset = seg * continuous_input_len;

                // 计算other偏移 - 修复后的逻辑 (同上)
                uint32_t other_offset = 0;
                uint32_t input_start_pos = seg * continuous_input_len;

                uint32_t coords[10];
                uint32_t temp_pos = input_start_pos;
                for(int dim = input_dims; dim >= 1; dim--) {
                    coords[dim-1] = temp_pos % input_shape[dim];
                    temp_pos /= input_shape[dim];
                }

                uint32_t other_stride = 1;
                for(int dim = other_dims; dim >= 1; dim--) {
                    uint32_t other_dim_size = other_shape[dim];
                    int input_dim_idx = dim + (input_dims - other_dims);
                    uint32_t coord = (input_dim_idx >= 1 && input_dim_idx <= input_dims) ? coords[input_dim_idx-1] : 0;

                    if(other_dim_size == 1) {
                        coord = 0;
                    }

                    other_offset += coord * other_stride;
                    other_stride *= other_dim_size;
                }

                // PRINTF("%d %d %d %d\n",input_offset, other_offset,continuous_input_len, process_mode);
                op.Process(input_offset, other_offset, input_offset, continuous_input_len);
            }
            op.Release();
        }
    }
}