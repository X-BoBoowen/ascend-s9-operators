
#include "glu_grad_jvp_tiling.h"
#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"
#include "graph/attr_value.h" 

#include <vector>

#include "register/tilingdata_base.h"
#include "tiling/tiling_api.h"


namespace optiling {
static ge::graphStatus TilingFunc(gert::TilingContext* context)
{
    size_t usrSize = 256;
  auto ascendcPlatform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    uint32_t sysWorkspaceSize = ascendcPlatform.GetLibApiWorkSpaceSize();
    size_t *currentWorkspace = context->GetWorkspaceSizes(1); // 通过框架获取workspace的指针，GetWorkspaceSizes入参为所需workspace的块数。当前限制使用一块。
    currentWorkspace[0] = usrSize + sysWorkspaceSize; // 设置总的workspace的数值大小，总的workspace空间由框架来申请并管理。
  uint32_t aivNum = ascendcPlatform.GetCoreNumAiv();
  context->SetBlockDim(aivNum);

  GluGradJvpTilingData tiling;
  
  uint32_t arrInput[8];
  int64_t dim_attr = 0;
  const gert::StorageShape* half_shape = context->GetInputShape(1);
  const gert::StorageShape* input_shape = context->GetInputShape(2);
  arrInput[0] = static_cast<uint32_t>(input_shape->GetStorageShape().GetDimNum());
  for (int i = 0; i < input_shape->GetStorageShape().GetDimNum(); i++)
  {
    arrInput[i+1] = static_cast<uint32_t>(input_shape->GetStorageShape().GetDim(i));
    if(input_shape->GetStorageShape().GetDim(i) != half_shape->GetStorageShape().GetDim(i)) {
        dim_attr = i;
    }
  }

  ge::DataType tensor_dtype = context->GetInputDesc(0)->GetDataType();
  uint32_t dtype_flag = 1;
  if(tensor_dtype == ge::DT_FLOAT16) {
      context->SetTilingKey(1);
      dtype_flag = 1;
  } else if(tensor_dtype == ge::DT_FLOAT) {
      context->SetTilingKey(2);
      dtype_flag = 2;
  } else {
      context->SetTilingKey(3);
      dtype_flag = 3;
  }

  tiling.set_data_type(dtype_flag);
  tiling.set_dim(static_cast<uint32_t>(dim_attr));
  tiling.set_input_shape(arrInput);

  tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());
  context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());
  std::cout << "ndim: " << arrInput[0] << " dim: " << dim_attr << " dtype_flag: " << dtype_flag << std::endl;
    
    // for(int i = 1 ; i <= 4; i++) {
    //     std::vector<int64_t> shape_vec = {i*1024};
    //     ge::Shape shape(shape_vec);
    //     uint32_t maxValue = 0;
    //     uint32_t minValue = 0;
    //     AscendC::GetSigmoidMaxMinTmpSize(shape, 4, false, maxValue, minValue);
    //     std::cout << "size: " << i*1024 << " max: " << maxValue << " min: " << minValue << std::endl;
    // }
    // for(int i = 1 ; i <= 4; i++) {
    //     std::vector<int64_t> shape_vec = {i*1024};
    //     ge::Shape shape(shape_vec);
    //     uint32_t maxValue = 0;
    //     uint32_t minValue = 0;
    //     AscendC::GetSigmoidMaxMinTmpSize(shape, 2, false, maxValue, minValue);
    //     std::cout << "size: " << i*1024 << " max: " << maxValue << " min: " << minValue << std::endl;
    // }
    
  return ge::GRAPH_SUCCESS;
}
}



namespace ge {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    const gert::Shape* x1_shape = context->GetInputShape(0);
    gert::Shape* y_shape = context->GetOutputShape(0);
    *y_shape = *x1_shape;
    return GRAPH_SUCCESS;
}
static ge::graphStatus InferDataType(gert::InferDataTypeContext *context)
{
const auto inputDataType = context->GetInputDataType(0);
context->SetOutputDataType(0, inputDataType);
return ge::GRAPH_SUCCESS;
}
}


namespace ops {
class GluGradJvp : public OpDef {
public:
    explicit GluGradJvp(const char* name) : OpDef(name)
    {
        this->Input("x_grad")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("y_grad")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("x")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("v_y")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("v_x")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("jvp_out")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND, ge::FORMAT_ND});
        this->Attr("dim").AttrType(OPTIONAL).Int(-1);

        this->SetInferShape(ge::InferShape).SetInferDataType(ge::InferDataType);

        this->AICore()
            .SetTiling(optiling::TilingFunc);
        this->AICore().AddConfig("ascend910b");

    }
};

OP_ADD(GluGradJvp);
}
