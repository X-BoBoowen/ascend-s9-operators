
#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(GluGradJvpTilingData)
  TILING_DATA_FIELD_DEF(uint32_t, data_type); // 1-fp16 2-fp32 3-bf16
  TILING_DATA_FIELD_DEF(uint32_t, dim); 
  TILING_DATA_FIELD_DEF_ARR(uint32_t, 8, input_shape);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(GluGradJvp, GluGradJvpTilingData)
}
