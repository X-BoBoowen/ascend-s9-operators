#include "kernel_operator.h"

using namespace AscendC;

__aicore__ inline int align_to(int a, int b) {
    return (a + b - 1) / b * b;
}

template<typename T>
class KernelGluGradJvp {
public:
    __aicore__ inline KernelGluGradJvp() {}
    
    __aicore__ inline void Init(GM_ADDR x_grad, GM_ADDR y_grad, GM_ADDR x, GM_ADDR v_y, GM_ADDR v_x, GM_ADDR jvp_out)
    {
        xGradGm.SetGlobalBuffer((__gm__ T *)x_grad);
        yGradGm.SetGlobalBuffer((__gm__ T *)y_grad);
        xGm.SetGlobalBuffer((__gm__ T *)x);
        vYGm.SetGlobalBuffer((__gm__ T *)v_y);
        vXGm.SetGlobalBuffer((__gm__ T *)v_x);
        jvpOutGm.SetGlobalBuffer((__gm__ T *)jvp_out);
        
        // 合并后的缓冲区初始化
        pipe.InitBuffer(inQueue, BUFFER_NUM, 6 * chunksize * sizeof(T));
        pipe.InitBuffer(outQueue, BUFFER_NUM, 2 * chunksize * sizeof(T)); 
        if(sizeof(T) == 2) {
            pipe.InitBuffer(workQueue, BUFFER_NUM, 8 * chunksize * sizeof(float)); // max 1600
        } else {
            pipe.InitBuffer(workQueue, BUFFER_NUM, chunksize * sizeof(float)); // max 2048
        }
    }
    
    __aicore__ inline void ProcessSlice(int input_offset1, int input_offset2, int jvp_out_offset, int size)
    {
        int loop = (size + chunksize - 1) / chunksize;
        int tile = size % chunksize;
        tile = tile == 0 ? chunksize : tile;
        this->input_offset1 = input_offset1;
        this->input_offset2 = input_offset2;
        this->single_offset = jvp_out_offset;
        
        for(int i = 0; i != loop - 1; i++) {
            CopyIn(i * chunksize, chunksize);
            Compute(chunksize);
            CopyOut(i * chunksize, chunksize);
        }
        
        // 处理最后一块
        CopyIn((loop - 1) * chunksize, align_to(tile, 256/sizeof(T)));
        Compute(align_to(tile, block_len));
        if(tile % block_len) {
            CopyOutPad((loop - 1) * chunksize, tile);
        } else {
            CopyOut((loop - 1) * chunksize, tile);
        }
    }

    __aicore__ inline void Process(int input_offset1, int input_offset2, int jvp_out_offset, int size)
    {
        LocalTensor<T> combinedLocal = inQueue.AllocTensor<T>();
        DataCopy(combinedLocal, xGm[input_offset1], 2 * size);
        DataCopy(combinedLocal[2*chunksize], vXGm[input_offset1], 2 * size);
        DataCopy(combinedLocal[4*chunksize], vYGm[jvp_out_offset], size);
        DataCopy(combinedLocal[5*chunksize], xGradGm[input_offset1], size);
        inQueue.EnQue(combinedLocal);
        inQueue.DeQue<T>();

        LocalTensor<T> jvpOutLocal1 = outQueue.AllocTensor<T>();
        LocalTensor<float> workLocal = workQueue.AllocTensor<float>();

        LocalTensor<T> a = combinedLocal;
        LocalTensor<T> b = combinedLocal[size];
        LocalTensor<T> da = combinedLocal[2*chunksize];        
        LocalTensor<T> db = combinedLocal[2*chunksize + size];        
        LocalTensor<T> dgrad_glu = combinedLocal[4*chunksize]; 
        LocalTensor<T> grad_x_a = combinedLocal[5*chunksize];  
        LocalTensor<T> jvpOutLocal2 = jvpOutLocal1[size];

        if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {
            // 分配float工作空间
            LocalTensor<float> a_f = workLocal;                       
            LocalTensor<float> b_f = workLocal[size];             
            LocalTensor<float> da_f = workLocal[2*chunksize];              
            LocalTensor<float> db_f = workLocal[2*chunksize + size];     
            LocalTensor<float> dgrad_glu_f = workLocal[4*chunksize];     
            LocalTensor<float> grad_x_a_f = workLocal[5*chunksize];        
            LocalTensor<float> tmp1 = workLocal[6*chunksize];       
            LocalTensor<float> tmp2 = workLocal[7*chunksize]; 

            // 转换输入为float
            Cast(workLocal, combinedLocal, RoundMode::CAST_NONE, 2*size);
            Cast(workLocal[2*chunksize], combinedLocal[2*chunksize], RoundMode::CAST_NONE, 2*size);
            Cast(workLocal[4*chunksize], combinedLocal[4*chunksize], RoundMode::CAST_NONE, size);
            Cast(workLocal[5*chunksize], combinedLocal[5*chunksize], RoundMode::CAST_NONE, size);

            // 步骤1：计算 sig_b = sigmoid(b)
            Sigmoid(b_f, b_f, size);

            // 步骤2：计算 db_neg_sig_b = db * (1 - sigmoid(b))
            Muls(tmp1, b_f, -1.0f, size);       // tmp1 = -sigmoid(b)
            Adds(tmp1, tmp1, 1.0f, size);         // tmp1 = 1 - sigmoid(b)
            Mul(tmp2, dgrad_glu_f, b_f, size);
            Mul(dgrad_glu_f, db_f, tmp1, size);          // tmp2 = db * (1 - sigmoid(b))             // result_a = dgrad_glu * sig_b
            // Mul(tmp1, grad_x_a_f, tmp2, size);                    // tmp1 = grad_x_a * db_neg_sig_b
            // Add(result_a, result_a, tmp1, size);                  // result_a = dgrad_glu * sig_b + grad_x_a * db_neg_sig_b
            MulAddDst(tmp2, grad_x_a_f, dgrad_glu_f, size);
            
            // 步骤4：计算 glu = a * sigmoid(b)
            Mul(dgrad_glu_f, a_f, b_f, size);                          // tmp2 = glu = a * sig_b

            // 步骤5：计算 dgrad_x_b的第一部分 = dgrad_x_a * (a - glu)
            Sub(a_f, a_f, dgrad_glu_f, size);                          // a = a - glu
            Mul(a_f, tmp2, a_f, size);      // jvpOutLocal2 = dgrad_x_a * (a - glu)

            // 步骤7：计算 glu * db * (1 - sig_b)
            Mul(dgrad_glu_f, dgrad_glu_f, db_f, size);
            Sub(da_f, da_f, dgrad_glu_f, size);
            Mul(tmp1, da_f, tmp1, size);                     // tmp1 = da*(1-sig_b) - glu*db*(1-sig_b)

            // 步骤10：计算最终的 dgrad_x_b
            MulAddDst(a_f, grad_x_a_f, tmp1, size);      // jvpOutLocal2 = dgrad_x_a*(a-glu) + grad_x_a*[...]
            

            // 转换回目标类型
            Cast(jvpOutLocal1, tmp2, RoundMode::CAST_RINT, size);
            Cast(jvpOutLocal2, a_f, RoundMode::CAST_RINT, size);

        } else {
            // 直接使用目标类型计算             
            LocalTensor<T> tmp1 = workLocal;     

            // 步骤1：计算 sig_b = sigmoid(b)
            Sigmoid(b, b, size);

            // 步骤2：计算 db_neg_sig_b = db * (1 - sigmoid(b))
            Muls(tmp1, b, (T)(-1.0), size);               // tmp1 = -sigmoid(b)
            Adds(tmp1, tmp1, (T)1.0, size);                   // tmp1 = 1 - sigmoid(b)
            Mul(jvpOutLocal1, dgrad_glu, b, size);        // jvpOutLocal1 = dgrad_glu * sig_b
            Mul(dgrad_glu, db, tmp1, size);                        // tmp2 = db * (1 - sigmoid(b))

            // 步骤3：计算 dgrad_x_a = dgrad_glu * sig_b + grad_x_a * db_neg_sig_b
            MulAddDst(jvpOutLocal1, grad_x_a, dgrad_glu, size);       // jvpOutLocal1 = dgrad_glu * sig_b + grad_x_a * db_neg_sig_b

            // 步骤4：计算 glu = a * sigmoid(b)
            Mul(dgrad_glu, a, b, size);                         // glu = a * sig_b

            // 步骤5：计算 dgrad_x_b的第一部分 = dgrad_x_a * (a - glu)
            Sub(a, a, dgrad_glu, size);                          // a = a - glu
            Mul(jvpOutLocal2, jvpOutLocal1, a, size);      // jvpOutLocal2 = dgrad_x_a * (a - glu)

            // 步骤7：计算 glu * db * (1 - sig_b)
            Mul(dgrad_glu, dgrad_glu, db, size);
            Sub(da, da, dgrad_glu, size);
            Mul(tmp1, da, tmp1, size);                     // tmp1 = da*(1-sig_b) - glu*db*(1-sig_b)

            // 步骤10：计算最终的 dgrad_x_b
            MulAddDst(jvpOutLocal2, grad_x_a, tmp1, size);      // jvpOutLocal2 = dgrad_x_a*(a-glu) + grad_x_a*[...]
        }
        outQueue.EnQue(jvpOutLocal1);
        workQueue.FreeTensor(workLocal);
        inQueue.FreeTensor(combinedLocal);

        outQueue.DeQue<T>();
        DataCopy(jvpOutGm[input_offset1], jvpOutLocal1, 2*size);
        outQueue.FreeTensor(jvpOutLocal1);
    }

    __aicore__ inline void ProcessSlice1(int input_offset1, int input_offset2, int jvp_out_offset, int size, int lines)
    {
        this->input_offset1 = input_offset1;
        this->input_offset2 = input_offset2;
        this->single_offset = jvp_out_offset;
    
        // 处理最后一块
        CopyInLines(size, size, lines);
        Compute(align_to(size, block_len) * lines);
        CopyOutLines(size, size, lines);
    }
    __aicore__ inline void ProcessSlice2(int input_offset1, int input_offset2, int jvp_out_offset, int size, int lines)
    {
        this->input_offset1 = input_offset1;
        this->input_offset2 = input_offset2;
        this->single_offset = jvp_out_offset;
        
        // 处理最后一块
        CopyInLines(align_to(size, block_len), size, lines);
        Compute(align_to(size, block_len) * lines);
        CopyOutPadLines(align_to(size, block_len), size, lines);
    }

private:
    __aicore__ inline void CopyInLines(int len, int size, int lines)
    {
        LocalTensor<T> combinedLocal = inQueue.AllocTensor<T>();
        DataCopyParams copyParams;
        copyParams.blockCount = lines;
        copyParams.blockLen = len / block_len;
        copyParams.srcStride = (align_to(2*size, block_len) - len) / block_len;
        copyParams.dstStride = 0;
        // DumpTensor(xGm[input_offset1+2*len], 0, 16);
        DataCopy(combinedLocal, xGm[input_offset1], copyParams);
        // DumpTensor(combinedLocal[len], 1, 16);
        DataCopy(combinedLocal[chunksize], xGm[input_offset2], copyParams);
        DataCopy(combinedLocal[2*chunksize], vXGm[input_offset1], copyParams);
        DataCopy(combinedLocal[3*chunksize], vXGm[input_offset2], copyParams);
        DataCopy(combinedLocal[4*chunksize], vYGm[single_offset], len*lines);
        DataCopy(combinedLocal[5*chunksize], xGradGm[input_offset1], copyParams);
        inQueue.EnQue(combinedLocal);
    }

    __aicore__ inline void CopyOutLines(int len, int size, int lines)
    {
        DataCopyParams copyParams;
        copyParams.blockCount = lines;
        copyParams.blockLen = len / block_len;
        copyParams.srcStride = 0;
        copyParams.dstStride = (align_to(2*size, block_len) - len) / block_len;

        LocalTensor<T> jvpOutLocal = outQueue.DeQue<T>();
        DataCopy(jvpOutGm[input_offset1], jvpOutLocal, copyParams);
        DataCopy(jvpOutGm[input_offset2], jvpOutLocal[chunksize], copyParams);
        outQueue.FreeTensor(jvpOutLocal);
    }
    
    __aicore__ inline void CopyOutPadLines(int len, int size, int lines)
    {
        DataCopyExtParams copyParams{static_cast<uint16_t>(lines), static_cast<uint32_t>(size * sizeof(T)), 0, 0, 0};
        LocalTensor<T> jvpOutLocal = outQueue.DeQue<T>();
        DataCopyPad(jvpOutGm[input_offset1], jvpOutLocal, copyParams);
        DataCopyPad(jvpOutGm[input_offset2], jvpOutLocal[chunksize], copyParams);
        outQueue.FreeTensor(jvpOutLocal);
    }

    __aicore__ inline void CopyIn(int offset, int len)
    {
        LocalTensor<T> combinedLocal = inQueue.AllocTensor<T>();
        
        DataCopy(combinedLocal, xGm[input_offset1 + offset], len);
        DataCopy(combinedLocal[chunksize], xGm[input_offset2 + offset], len);
        DataCopy(combinedLocal[2*chunksize], vXGm[input_offset1 + offset], len);
        DataCopy(combinedLocal[3*chunksize], vXGm[input_offset2 + offset], len);
        DataCopy(combinedLocal[4*chunksize], vYGm[single_offset + offset], len);
        DataCopy(combinedLocal[5*chunksize], xGradGm[input_offset1 + offset], len);
        inQueue.EnQue(combinedLocal);
    }
    
    __aicore__ inline void Compute(int len)
    {
        LocalTensor<T> combinedLocal = inQueue.DeQue<T>();
        LocalTensor<T> jvpOutLocal1 = outQueue.AllocTensor<T>();
        LocalTensor<float> workLocal = workQueue.AllocTensor<float>();

        // 使用offset访问不同部分
        LocalTensor<T> a = combinedLocal;
        LocalTensor<T> b = combinedLocal[chunksize];
        LocalTensor<T> da = combinedLocal[2*chunksize];        
        LocalTensor<T> db = combinedLocal[3*chunksize];        
        LocalTensor<T> dgrad_glu = combinedLocal[4*chunksize]; 
        LocalTensor<T> grad_x_a = combinedLocal[5*chunksize];  
        LocalTensor<T> jvpOutLocal2 = jvpOutLocal1[chunksize];

        if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {
            // 分配float工作空间
            LocalTensor<float> a_f = workLocal;                       
            LocalTensor<float> b_f = workLocal[chunksize];             
            LocalTensor<float> da_f = workLocal[2*chunksize];              
            LocalTensor<float> db_f = workLocal[3*chunksize];     
            LocalTensor<float> dgrad_glu_f = workLocal[4*chunksize];     
            LocalTensor<float> grad_x_a_f = workLocal[5*chunksize];          
            LocalTensor<float> tmp1 = workLocal[6*chunksize];       
            LocalTensor<float> tmp2 = workLocal[7*chunksize]; 

            // 转换输入为float
            Cast(workLocal, combinedLocal, RoundMode::CAST_NONE, len);
            Cast(workLocal[chunksize], combinedLocal[chunksize], RoundMode::CAST_NONE, len);
            Cast(workLocal[2*chunksize], combinedLocal[2*chunksize], RoundMode::CAST_NONE, len);
            Cast(workLocal[3*chunksize], combinedLocal[3*chunksize], RoundMode::CAST_NONE, len);
            Cast(workLocal[4*chunksize], combinedLocal[4*chunksize], RoundMode::CAST_NONE, len);
            Cast(workLocal[5*chunksize], combinedLocal[5*chunksize], RoundMode::CAST_NONE, len);

            // 步骤1：计算 sig_b = sigmoid(b)
            Sigmoid(b_f, b_f, len);

            // 步骤2：计算 db_neg_sig_b = db * (1 - sigmoid(b))
            Muls(tmp1, b_f, -1.0f, len);       // tmp1 = -sigmoid(b)
            Adds(tmp1, tmp1, 1.0f, len);         // tmp1 = 1 - sigmoid(b)
            Mul(tmp2, dgrad_glu_f, b_f, len);
            Mul(dgrad_glu_f, db_f, tmp1, len);          // tmp2 = db * (1 - sigmoid(b))

            // 步骤3：计算 dgrad_x_a = dgrad_glu * sig_b + grad_x_a * db_neg_sig_b
            // Mul(tmp1, grad_x_a_f, tmp2, len);                    // tmp1 = grad_x_a * db_neg_sig_b
            // Add(result_a, result_a, tmp1, len);                  // result_a = dgrad_glu * sig_b + grad_x_a * db_neg_sig_b
            MulAddDst(tmp2, grad_x_a_f, dgrad_glu_f, len);
            
            // 步骤4：计算 glu = a * sigmoid(b)
            Mul(dgrad_glu_f, a_f, b_f, len);                          // tmp2 = glu = a * sig_b

            // 步骤5：计算 dgrad_x_b的第一部分 = dgrad_x_a * (a - glu)
            Sub(a_f, a_f, dgrad_glu_f, len);                          // a = a - glu
            Mul(a_f, tmp2, a_f, len);      // jvpOutLocal2 = dgrad_x_a * (a - glu)

            // 步骤7：计算 glu * db * (1 - sig_b)
            Mul(dgrad_glu_f, dgrad_glu_f, db_f, len);
            Sub(da_f, da_f, dgrad_glu_f, len);
            Mul(tmp1, da_f, tmp1, len);                     // tmp1 = da*(1-sig_b) - glu*db*(1-sig_b)

            // 步骤10：计算最终的 dgrad_x_b
            MulAddDst(a_f, grad_x_a_f, tmp1, len);      // jvpOutLocal2 = dgrad_x_a*(a-glu) + grad_x_a*[...]
            

            // 转换回目标类型
            Cast(jvpOutLocal1, tmp2, RoundMode::CAST_RINT, len);
            Cast(jvpOutLocal2, a_f, RoundMode::CAST_RINT, len);

        } else {
            // 直接使用目标类型计算             
            LocalTensor<T> tmp1 = workLocal;     

            // 步骤1：计算 sig_b = sigmoid(b)
            Sigmoid(b, b, len);

            // 步骤2：计算 db_neg_sig_b = db * (1 - sigmoid(b))
            Muls(tmp1, b, (T)(-1.0), len);               // tmp1 = -sigmoid(b)
            Adds(tmp1, tmp1, (T)1.0, len);                   // tmp1 = 1 - sigmoid(b)
            Mul(jvpOutLocal1, dgrad_glu, b, len);        // jvpOutLocal1 = dgrad_glu * sig_b
            Mul(dgrad_glu, db, tmp1, len);                        // tmp2 = db * (1 - sigmoid(b))

            // 步骤3：计算 dgrad_x_a = dgrad_glu * sig_b + grad_x_a * db_neg_sig_b
            MulAddDst(jvpOutLocal1, grad_x_a, dgrad_glu, len);       // jvpOutLocal1 = dgrad_glu * sig_b + grad_x_a * db_neg_sig_b

            // 步骤4：计算 glu = a * sigmoid(b)
            Mul(dgrad_glu, a, b, len);                         // glu = a * sig_b

            // 步骤5：计算 dgrad_x_b的第一部分 = dgrad_x_a * (a - glu)
            Sub(a, a, dgrad_glu, len);                          // a = a - glu
            Mul(jvpOutLocal2, jvpOutLocal1, a, len);      // jvpOutLocal2 = dgrad_x_a * (a - glu)

            // 步骤7：计算 glu * db * (1 - sig_b)
            Mul(dgrad_glu, dgrad_glu, db, len);
            Sub(da, da, dgrad_glu, len);
            Mul(tmp1, da, tmp1, len);                     // tmp1 = da*(1-sig_b) - glu*db*(1-sig_b)

            // 步骤10：计算最终的 dgrad_x_b
            MulAddDst(jvpOutLocal2, grad_x_a, tmp1, len);      // jvpOutLocal2 = dgrad_x_a*(a-glu) + grad_x_a*[...]
        }


        outQueue.EnQue(jvpOutLocal1);
        workQueue.FreeTensor(workLocal);
        inQueue.FreeTensor(combinedLocal);
    }

    
    __aicore__ inline void CopyOut(int offset, int len)
    {
        LocalTensor<T> jvpOutLocal = outQueue.DeQue<T>();
        DataCopy(jvpOutGm[offset + input_offset1], jvpOutLocal, len);
        DataCopy(jvpOutGm[offset + input_offset2], jvpOutLocal[chunksize], len);
        outQueue.FreeTensor(jvpOutLocal);
    }
    
    __aicore__ inline void CopyOutPad(int offset, int len)
    {
        DataCopyExtParams copyParams{1, static_cast<uint32_t>(len * sizeof(T)), 0, 0, 0};
        LocalTensor<T> jvpOutLocal = outQueue.DeQue<T>();
        DataCopyPad(jvpOutGm[offset + input_offset1], jvpOutLocal, copyParams);
        DataCopyPad(jvpOutGm[offset + input_offset2], jvpOutLocal[chunksize], copyParams);
        outQueue.FreeTensor(jvpOutLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, 1> inQueue;    // 合并的输入队列
    TQue<QuePosition::VECOUT, 1> outQueue; // 输出队列
    TQue<QuePosition::VECIN, 1> workQueue; // 合并的工作队列
    
    GlobalTensor<T> xGradGm;
    GlobalTensor<T> yGradGm;
    GlobalTensor<T> xGm;
    GlobalTensor<T> vYGm;
    GlobalTensor<T> vXGm;
    GlobalTensor<T> jvpOutGm;
    
    int chunksize = sizeof(T) == 2 ? 1792 : 2560;
    int BUFFER_NUM = 2;
    int input_offset1, input_offset2, single_offset;
    int block_len = 32/sizeof(T);
};

extern "C" __global__ __aicore__ void glu_grad_jvp(GM_ADDR x_grad, GM_ADDR y_grad, GM_ADDR x, GM_ADDR v_y, GM_ADDR v_x, GM_ADDR jvp_out, GM_ADDR workspace, GM_ADDR tiling) {
    // Note: All size/offset/count variables are changed to 'int' to avoid type ambiguity.
    GET_TILING_DATA(tiling_data, tiling);
    const uint32_t* input_shape = tiling_data.input_shape;
    const uint32_t data_type = tiling_data.data_type;
    const int dim = (int)tiling_data.dim;
    
    int blockIdx = GetBlockIdx();
    int blockDim = GetBlockNum();
    
    int threshold = (data_type == 2) ? 81920 : 163840;
    int chunksize = (data_type == 2) ? 2560 : 1792;
    int total_dims = (int)input_shape[0];
    int dim_size = (int)input_shape[dim + 1];
    
    int strides[8];
    strides[total_dims - 1] = 1;
    for (int i = total_dims - 2; i >= 0; i--) {
        strides[i] = strides[i + 1] * (int)input_shape[i + 2];
    }
    
    int total_elements = 1;
    for (int i = 1; i <= total_dims; i++) {
        total_elements *= (int)input_shape[i];
    }
    
    if (dim == 0) {
        int cacheline;
        if (data_type == 2) { // float
            cacheline = 64;
        } else { // half or bfloat16
            cacheline = 128;
        }

        int half_elements = total_elements / 2;
        int chunks = (half_elements + cacheline - 1) / cacheline;
        int base_chunks = chunks / blockDim;
        int tile_chunks = chunks % blockDim;
        int start = (base_chunks * blockIdx + min(blockIdx, tile_chunks)) * cacheline;
        int len = min(half_elements - start, (base_chunks + (blockIdx < tile_chunks)) * cacheline);

        if(len <= 0) return;

        int input_offset1 = start;
        int input_offset2 = start + half_elements;
        int jvp_out_offset = start;
        GlobalTensor<int32_t> workGm;
        workGm.SetGlobalBuffer((__gm__ int32_t *)workspace);
        bool process_in_reverse_chunks = (workGm(0)%2) && (len > threshold);

        if (TILING_KEY_IS(2)) { // float
            KernelGluGradJvp<float> op;
            op.Init(x_grad, y_grad, x, v_y, v_x, jvp_out);
            
            if (process_in_reverse_chunks) {
                int num_chunks = (len + threshold - 1) / threshold;
                for (int i = num_chunks - 1; i >= 0; --i) {
                    int chunk_offset = i * threshold;
                    int chunk_len = min(threshold, len - chunk_offset);
                    op.ProcessSlice((uint32_t)(input_offset1 + chunk_offset), (uint32_t)(input_offset2 + chunk_offset), (uint32_t)(jvp_out_offset + chunk_offset), (uint32_t)chunk_len);
                }
            } else {
                op.ProcessSlice((uint32_t)input_offset1, (uint32_t)input_offset2, (uint32_t)jvp_out_offset, (uint32_t)len);
            }
        } else if (TILING_KEY_IS(1)) { // half
            KernelGluGradJvp<half> op;
            op.Init(x_grad, y_grad, x, v_y, v_x, jvp_out);

            if (process_in_reverse_chunks) {
                int num_chunks = (len + threshold - 1) / threshold;
                for (int i = num_chunks - 1; i >= 0; --i) {
                    int chunk_offset = i * threshold;
                    int chunk_len = min(threshold, len - chunk_offset);
                    op.ProcessSlice((uint32_t)(input_offset1 + chunk_offset), (uint32_t)(input_offset2 + chunk_offset), (uint32_t)(jvp_out_offset + chunk_offset), (uint32_t)chunk_len);
                }
            } else {
                op.ProcessSlice((uint32_t)input_offset1, (uint32_t)input_offset2, (uint32_t)jvp_out_offset, (uint32_t)len);
            }
        } else if (TILING_KEY_IS(3)) { // bfloat16
            KernelGluGradJvp<bfloat16_t> op;
            op.Init(x_grad, y_grad, x, v_y, v_x, jvp_out);
            
            if (process_in_reverse_chunks) {
                int num_chunks = (len + threshold - 1) / threshold;
                for (int i = num_chunks - 1; i >= 0; --i) {
                    int chunk_offset = i * threshold;
                    int chunk_len = min(threshold, len - chunk_offset);
                    op.ProcessSlice((uint32_t)(input_offset1 + chunk_offset), (uint32_t)(input_offset2 + chunk_offset), (uint32_t)(jvp_out_offset + chunk_offset), (uint32_t)chunk_len);
                }
            } else {
                op.ProcessSlice((uint32_t)input_offset1, (uint32_t)input_offset2, (uint32_t)jvp_out_offset, (uint32_t)len);
            }
        }
        if(blockIdx == 0) workGm(0) += 1;
    } else {
        // dim!=0: all calculations now use 'int'
        int split_size = dim_size / 2;
        int elements_per_split = strides[dim];
        int total_splits = total_elements / (dim_size * elements_per_split);
        
        int splits_per_core = total_splits / blockDim;
        int remaining_splits = total_splits % blockDim;
        
        int start_split, end_split;
        if (blockIdx < remaining_splits) {
            start_split = blockIdx * (splits_per_core + 1);
            end_split = start_split + splits_per_core + 1;
        } else {
            start_split = remaining_splits * (splits_per_core + 1) + (blockIdx - remaining_splits) * splits_per_core;
            end_split = start_split + splits_per_core;
        }

        int num_splits_for_core = (end_split > start_split) ? (end_split - start_split) : 0;
        if (num_splits_for_core == 0) {
            return;
        }
        int split_elements = split_size * elements_per_split;
        int core_total_elements = num_splits_for_core * split_elements;

        GlobalTensor<int32_t> workGm;
        workGm.SetGlobalBuffer((__gm__ int32_t *)workspace);
        bool process_in_reverse = (workGm(0)%2) && (core_total_elements > threshold);

        // --- FIX STARTS HERE: Restored separate logic for each data type ---

        if (TILING_KEY_IS(2)) { // float
            KernelGluGradJvp<float> op;
            op.Init(x_grad, y_grad, x, v_y, v_x, jvp_out);
            int alignment = 8;
            
            if (process_in_reverse) { // REVERSE LOGIC
                if (align_to(split_elements, alignment) <= (chunksize / 2)) {
                    int lines = chunksize / (2 * align_to(split_elements, alignment));
                    if (lines == 0) lines = 1;
                    int last_block_start = start_split + ((num_splits_for_core - 1) / lines) * lines;

                    for (int s = last_block_start; s >= start_split; s -= lines) {
                        int num_lines_in_block = min(lines, end_split - s);
                        int base_offset = s * dim_size * elements_per_split;
                        if(split_elements % alignment) op.ProcessSlice2((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(s * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                        else op.ProcessSlice1((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(s * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                    }
                } else if (split_elements % alignment == 0 && split_elements <= chunksize) {
                    for (int i = 0; i < num_splits_for_core; ++i) {
                        int split = end_split - 1 - i;
                        int base_offset = split * dim_size * elements_per_split;
                        op.Process((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                } else {
                    for (int i = 0; i < num_splits_for_core; ++i) {
                        int split = end_split - 1 - i;
                        int base_offset = split * dim_size * elements_per_split;
                        op.ProcessSlice((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                }
            } else { // FORWARD LOGIC
                if (align_to(split_elements, alignment) <= (chunksize / 2)) {
                    int lines = chunksize / (2 * align_to(split_elements, alignment));
                    if (lines == 0) lines = 1;
                    for (int split = start_split; split < end_split; split += lines) {
                        int num_lines_in_block = min(lines, end_split - split);
                        int base_offset = split * dim_size * elements_per_split;
                        if(split_elements % alignment) op.ProcessSlice2((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                        else op.ProcessSlice1((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                    }
                } else if (split_elements % alignment == 0 && split_elements <= chunksize) {
                    for (int split = start_split; split < end_split; split++) {
                        int base_offset = split * dim_size * elements_per_split;
                        op.Process((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                } else {
                    for (int split = start_split; split < end_split; split++) {
                        int base_offset = split * dim_size * elements_per_split;
                        op.ProcessSlice((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                }
            }
        } else if (TILING_KEY_IS(1)) { // half
            KernelGluGradJvp<half> op;
            op.Init(x_grad, y_grad, x, v_y, v_x, jvp_out);
            int alignment = 16;
            
            if (process_in_reverse) { // REVERSE LOGIC
                if (align_to(split_elements, alignment) <= (chunksize / 2)) {
                    int lines = chunksize / (2 * align_to(split_elements, alignment));
                    if (lines == 0) lines = 1;
                    int last_block_start = start_split + ((num_splits_for_core - 1) / lines) * lines;

                    for (int s = last_block_start; s >= start_split; s -= lines) {
                        int num_lines_in_block = min(lines, end_split - s);
                        int base_offset = s * dim_size * elements_per_split;
                        if (split_elements % alignment) op.ProcessSlice2((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(s * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                        else op.ProcessSlice1((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(s * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                    }
                } else if (split_elements % alignment == 0 && split_elements <= chunksize) {
                    for (int i = 0; i < num_splits_for_core; ++i) {
                        int split = end_split - 1 - i;
                        int base_offset = split * dim_size * elements_per_split;
                        op.Process((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                } else {
                    for (int i = 0; i < num_splits_for_core; ++i) {
                        int split = end_split - 1 - i;
                        int base_offset = split * dim_size * elements_per_split;
                        op.ProcessSlice((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                }
            } else { // FORWARD LOGIC
                if (align_to(split_elements, alignment) <= (chunksize / 2)) {
                    int lines = chunksize / (2 * align_to(split_elements, alignment));
                    if (lines == 0) lines = 1;
                    for (int split = start_split; split < end_split; split += lines) {
                        int num_lines_in_block = min(lines, end_split - split);
                        int base_offset = split * dim_size * elements_per_split;
                        if (split_elements % alignment) op.ProcessSlice2((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                        else op.ProcessSlice1((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                    }
                } else if (split_elements % alignment == 0 && split_elements <= chunksize) {
                    for (int split = start_split; split < end_split; split++) {
                        int base_offset = split * dim_size * elements_per_split;
                        op.Process((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                } else {
                    for (int split = start_split; split < end_split; split++) {
                        int base_offset = split * dim_size * elements_per_split;
                        op.ProcessSlice((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                }
            }
        } else if(TILING_KEY_IS(3)) { // bfloat16
            KernelGluGradJvp<bfloat16_t> op;
            op.Init(x_grad, y_grad, x, v_y, v_x, jvp_out);
            int alignment = 16;
            
            if (process_in_reverse) { // REVERSE LOGIC
                if (align_to(split_elements, alignment) <= (chunksize / 2)) {
                    int lines = chunksize / (2 * align_to(split_elements, alignment));
                    if (lines == 0) lines = 1;
                    int last_block_start = start_split + ((num_splits_for_core - 1) / lines) * lines;

                    for (int s = last_block_start; s >= start_split; s -= lines) {
                        int num_lines_in_block = min(lines, end_split - s);
                        int base_offset = s * dim_size * elements_per_split;
                        if (split_elements % alignment) op.ProcessSlice2((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(s * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                        else op.ProcessSlice1((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(s * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                    }
                } else if (split_elements % alignment == 0 && split_elements <= chunksize) {
                    for (int i = 0; i < num_splits_for_core; ++i) {
                        int split = end_split - 1 - i;
                        int base_offset = split * dim_size * elements_per_split;
                        op.Process((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                } else {
                    for (int i = 0; i < num_splits_for_core; ++i) {
                        int split = end_split - 1 - i;
                        int base_offset = split * dim_size * elements_per_split;
                        op.ProcessSlice((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                }
            } else { // FORWARD LOGIC
                if (align_to(split_elements, alignment) <= (chunksize / 2)) {
                    int lines = chunksize / (2 * align_to(split_elements, alignment));
                    if (lines == 0) lines = 1;
                    for (int split = start_split; split < end_split; split += lines) {
                        int num_lines_in_block = min(lines, end_split - split);
                        int base_offset = split * dim_size * elements_per_split;
                        if (split_elements % alignment) op.ProcessSlice2((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                        else op.ProcessSlice1((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements, (uint32_t)num_lines_in_block);
                    }
                } else if (split_elements % alignment == 0 && split_elements <= chunksize) {
                    for (int split = start_split; split < end_split; split++) {
                        int base_offset = split * dim_size * elements_per_split;
                        op.Process((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                } else {
                    for (int split = start_split; split < end_split; split++) {
                        int base_offset = split * dim_size * elements_per_split;
                        op.ProcessSlice((uint32_t)base_offset, (uint32_t)(base_offset + split_elements), (uint32_t)(split * split_elements), (uint32_t)split_elements);
                    }
                }
            }
        }
    if(blockIdx == 0) workGm(0) += 1;
    }
}
